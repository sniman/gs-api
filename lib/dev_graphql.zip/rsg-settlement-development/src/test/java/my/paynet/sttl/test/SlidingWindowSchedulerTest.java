package my.paynet.sttl.test;

import my.paynet.sttl.config.Config;
import my.paynet.sttl.graphql.GraphQLClient;
import my.paynet.sttl.model.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import my.paynet.sttl.scheduler.SlidingWindowScheduler;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class SlidingWindowSchedulerTest {

    private Config config;
    private ScheduledExecutorService scheduler;
    private SlidingWindowScheduler slidingWindowScheduler;

    @BeforeEach
    public void setUp() {
        config = mock(Config.class);
        scheduler = mock(ScheduledExecutorService.class);
        slidingWindowScheduler = spy(new SlidingWindowScheduler(config));

        // Inject the mocked scheduler into the slidingWindowScheduler
        slidingWindowScheduler.setScheduler(scheduler);

        when(config.getWindow1StartTime()).thenReturn(LocalTime.of(0, 0));
        when(config.getWindow1EndTime()).thenReturn(LocalTime.of(23, 59));
        when(config.getWindow2StartTime()).thenReturn(LocalTime.of(0, 0));
        when(config.getWindow2EndTime()).thenReturn(LocalTime.of(23, 59));
    }

//    @Test
//    public void testCalculateInitialDelayWithinWindow() {
//        LocalDateTime now = LocalDateTime.of(2024, 7, 22, 12, 0);
//        LocalDateTime expectedStart = now.withHour(0).withMinute(0).withSecond(1).withNano(0);
//        long expectedDelay = 1;
//
//        LocalDateTime startDateTime = slidingWindowScheduler.getStartDateTime(now, SlidingWindowScheduler.WINDOW1);
//        assertEquals(expectedStart, startDateTime);
//
//        long initialDelay = slidingWindowScheduler.calculateInitialDelay(SlidingWindowScheduler.WINDOW1);
//        assertEquals(expectedDelay, initialDelay);
//    }

//    @Test
//    public void testCalculateInitialDelayOutsideWindow() {
//        LocalDateTime now = LocalDateTime.of(2024, 7, 22, 23, 59, 59);
//        LocalDateTime expectedStart = now.plusDays(1).withHour(0).withMinute(0).withSecond(0).withNano(0);
//        long expectedDelay = 1;
//
//        LocalDateTime startDateTime = slidingWindowScheduler.getStartDateTime(now, SlidingWindowScheduler.WINDOW1);
//        assertEquals(expectedStart, startDateTime.plusDays(1));
//
//        long initialDelay = slidingWindowScheduler.calculateInitialDelay(SlidingWindowScheduler.WINDOW1);
//        assertEquals(expectedDelay, initialDelay);
//    }
//
//    @Test
//    public void testScheduleWindow() {
//        doNothing().when(scheduler).schedule(any(Runnable.class), anyLong(), any());
//
//        slidingWindowScheduler.scheduleWindow(SlidingWindowScheduler.WINDOW1);
//
//        verify(scheduler, times(1)).schedule(any(Runnable.class), anyLong(), any());
//    }

//    @Test
//    public void testPerformTask() throws Exception {
//        LocalDateTime dateTime = LocalDateTime.parse("2024-07-22T12:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
//
//        GraphQLClient client = mock(GraphQLClient.class);
//        Response response = mock(Response.class);
//        when(client.query(anyString(), any(LocalDateTime.class))).thenReturn(response);
//
//        doReturn(client).when(slidingWindowScheduler).createGraphQLClient();
//        doNothing().when(slidingWindowScheduler).generateFile(any(Response.class), any(LocalDateTime.class), anyString());
//
//        boolean result = slidingWindowScheduler.performTask(SlidingWindowScheduler.WINDOW1, dateTime);
//
//        assertEquals(true, result);
//    }

//    @Test
//    public void testShutdown() throws InterruptedException {
//        doNothing().when(scheduler).shutdown();
//        doReturn(true).when(scheduler).awaitTermination(anyLong(), any(TimeUnit.class));
//
//        slidingWindowScheduler.shutdown();
//
//        verify(scheduler, times(1)).shutdown();
//        verify(scheduler, times(1)).awaitTermination(anyLong(), any(TimeUnit.class));
//    }

//    @Test
//    public void testRetryTask() {
//        SlidingWindowScheduler.RetryTask task = slidingWindowScheduler.new RetryTask(SlidingWindowScheduler.WINDOW1);
//        doNothing().when(scheduler).submit(task);
//
//        slidingWindowScheduler.retryTask(SlidingWindowScheduler.WINDOW1);
//
//        verify(scheduler, times(1)).submit(task);
//    }
}
