package my.paynet.sttl.test;

import org.ini4j.Ini;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Set;
import my.paynet.sttl.config.Config;
import my.paynet.sttl.config.ConfigManager;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ConfigManagerTest {

    private ConfigManager configManager;
    private Ini ini;
    private Ini.Section section;
    private Ini.Section holidaysSection;
    private String DEST_PATH="C:\\Users\\tuan.sauwern\\Documents\\NetBeansProjects\\sttl\\src\\main\\resources\\output";
    private String ARCHIVE_PATH="C:\\Users\\tuan.sauwern\\Documents\\NetBeansProjects\\sttl\\src\\main\\resources\\archive";
    private String KEY_FILE="C:\\Users\\tuan.sauwern\\Documents\\NetBeansProjects\\sttl\\src\\main\\resources\\key.dat";
    private String INI_FILE="C:\\Users\\tuan.sauwern\\Documents\\NetBeansProjects\\sttl\\src\\main\\resources\\rsgsttlconfig.ini";
    private String URL = "https://data-gateway.api.data-platform.nonprod.c0.paynet.my/query";
    @BeforeEach
    public void setUp() {
        configManager = Mockito.spy(new ConfigManager());
        ini = mock(Ini.class);
        section = mock(Ini.Section.class);
        holidaysSection = mock(Ini.Section.class);
    }

    @Test
    public void testLoadConfigurationValid() throws IOException {
        // Mocking Ini class and its methods
        doReturn(ini).when(configManager).loadIniFile(anyString());
        when(ini.get("mydebit")).thenReturn(section);
        when(ini.get("holidays")).thenReturn(holidaysSection);

        // Mocking section values
        when(section.get("graphql_url")).thenReturn("https://data-gateway.api.data-platform.nonprod.c0.paynet.my/query");
        when(section.get("graphql_schema_file")).thenReturn("graphql/mydebit.graphqls");
        when(section.get("graphql_query_file")).thenReturn("graphql/mydebit-query.graphql");
        when(section.get("keyfile")).thenReturn(KEY_FILE);
        when(section.get("connect_timeout")).thenReturn("5");
        when(section.get("read_timeout")).thenReturn("10");
        when(section.get("iv")).thenReturn("iJoemb91dkaf");
        when(section.get("graphql_api_key")).thenReturn("aUpvZW1iOTFka2FmTWLSOi4W0IzpuYUx6Fv4P11xXTJ7Z+FZZ49h2/9Oo/0qiEQP9+z2O6FM/Nw6mlaqEqjuAi61ar6CK4jHzU1i+xrmN46jt7M8YJhFyaPEC/s=");
        when(section.get("window2_start_time")).thenReturn("00:00:00");
        when(section.get("window1_start_time")).thenReturn("14:30:00");
        when(section.get("window2_end_time")).thenReturn("14:29:59");
        when(section.get("window1_end_time")).thenReturn("23:59:59");
        when(section.get("dest_path")).thenReturn(DEST_PATH);
        when(section.get("archive_path")).thenReturn(ARCHIVE_PATH);
        when(section.get("product")).thenReturn("MYDEBIT");

        // Performing the loadConfiguration method
        Config config = configManager.loadConfiguration(INI_FILE, "mydebit");

        // Asserting the configuration values
        assertNotNull(config);
        assertEquals(URL, config.getGraphqlUrl());
        assertEquals("graphql/mydebit.graphqls", config.getGraphqlSchemaFile());
        assertEquals("graphql/mydebit-query.graphql", config.getGraphqlQueryFile());
        assertEquals(KEY_FILE, config.getKeyfile());
        assertEquals(5, config.getConnectTimeout());
        assertEquals(10, config.getReadTimeout());
        assertEquals("iJoemb91dkaf", config.getIv());
        assertEquals("MYDEBIT", config.getProduct());
    }

    @Test
    public void testLoadConfigurationInvalid() throws IOException {
        // Mocking Ini class and its methods
        doReturn(ini).when(configManager).loadIniFile(anyString());
        when(ini.get("mydebit")).thenReturn(section);
        when(ini.get("holidays")).thenReturn(holidaysSection);

        // Mocking section values
        when(section.get("graphql_url")).thenReturn("");
        when(section.get("graphql_schema_file")).thenReturn("");
        when(section.get("graphql_query_file")).thenReturn("");
        when(section.get("keyfile")).thenReturn("");
        when(section.get("connect_timeout")).thenReturn("");
        when(section.get("read_timeout")).thenReturn("");
        when(section.get("iv")).thenReturn("");
        when(section.get("graphql_api_key")).thenReturn("");
        when(section.get("window2_start_time")).thenReturn("");
        when(section.get("window1_start_time")).thenReturn("");
        when(section.get("window2_end_time")).thenReturn("");
        when(section.get("window1_end_time")).thenReturn("");
        when(section.get("dest_path")).thenReturn("");
        when(section.get("archive_path")).thenReturn("");
        when(section.get("product")).thenReturn("");

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            configManager.loadConfiguration("path/to/iniFile", "mydebit");
        });

        assertTrue(exception.getMessage().contains("Invalid ciphertext length"));
    }

    @Test
    public void testValidateUrl() {
        List<String> missingFields = new ArrayList<>();
        List<String> invalidFields = new ArrayList<>();

        String validUrl = configManager.validateUrl("https://example.com", "graphql_url", missingFields, invalidFields);
        assertEquals("https://example.com", validUrl);
        assertTrue(missingFields.isEmpty());
        assertTrue(invalidFields.isEmpty());

        String invalidUrl = configManager.validateUrl("htp://example.com", "graphql_url", missingFields, invalidFields);
        assertEquals("htp://example.com", invalidUrl);
        assertTrue(missingFields.isEmpty());
        assertTrue(invalidFields.isEmpty());
    }

    @Test
    public void testValidateTime() {
        List<String> missingFields = new ArrayList<>();
        List<String> invalidFields = new ArrayList<>();

        String validTime = configManager.validateTime("14:30:00", "window1_start_time", missingFields, invalidFields);
        assertEquals("14:30:00", validTime);
        assertTrue(missingFields.isEmpty());
        assertTrue(invalidFields.isEmpty());

        String invalidTime = configManager.validateTime("25:30:00", "window1_start_time", missingFields, invalidFields);
        assertEquals("25:30:00", invalidTime);
        assertTrue(missingFields.isEmpty());
        assertFalse(invalidFields.isEmpty());
    }

    @Test
    public void testValidateIntField() {
        List<String> missingFields = new ArrayList<>();
        List<String> invalidFields = new ArrayList<>();

        int validInt = configManager.validateIntField("10", "connect_timeout", missingFields, invalidFields);
        assertEquals(10, validInt);
        assertTrue(missingFields.isEmpty());
        assertTrue(invalidFields.isEmpty());

        int invalidInt = configManager.validateIntField("abc", "connect_timeout", missingFields, invalidFields);
        assertEquals(0, invalidInt); // default value
        assertTrue(missingFields.isEmpty());
        assertFalse(invalidFields.isEmpty());
    }

    @Test
    public void testValidatePath() {
        List<String> missingFields = new ArrayList<>();
        List<String> invalidFields = new ArrayList<>();

        String validPath = configManager.validatePath(DEST_PATH, "dest_path", missingFields, invalidFields);
        assertEquals(DEST_PATH,validPath);
        assertTrue(missingFields.isEmpty());
        assertTrue(invalidFields.isEmpty());

        String invalidPath = configManager.validatePath("", "dest_path", missingFields, invalidFields);
        assertEquals(ConfigManager.NOB, invalidPath);
        assertFalse(missingFields.isEmpty());
        assertTrue(invalidFields.isEmpty());
    }

    @Test
    public void testIsValidHolidays() {
        when(holidaysSection.keySet()).thenReturn(Set.of("2024-01-01", "2024-12-25"));
        when(holidaysSection.get("2024-01-01")).thenReturn("New Year");
        when(holidaysSection.get("2024-12-25")).thenReturn("Christmas");

        assertTrue(configManager.isValidHolidays(holidaysSection));

        when(holidaysSection.keySet()).thenReturn(Set.of("invalid-date"));
        assertFalse(configManager.isValidHolidays(holidaysSection));
    }

    @Test
    public void testValidateProduct() {
        List<String> missingFields = new ArrayList<>();
        List<String> invalidFields = new ArrayList<>();

        String validProduct = configManager.validateProduct("MYDEBIT", "product", missingFields, invalidFields);
        assertEquals("MYDEBIT", validProduct);
        assertTrue(missingFields.isEmpty());
        assertTrue(invalidFields.isEmpty());

        String invalidProduct = configManager.validateProduct("INVALID", "product", missingFields, invalidFields);
        assertEquals("INVALID", invalidProduct);
        assertTrue(missingFields.isEmpty());
        assertFalse(invalidFields.isEmpty());
    }

    @Test
    public void testValidateIv() {
        List<String> missingFields = new ArrayList<>();
        List<String> invalidFields = new ArrayList<>();

        String validIv = configManager.validateIv("abcdefghijkl", "iv", missingFields, invalidFields);
        assertEquals("abcdefghijkl", validIv);
        assertTrue(missingFields.isEmpty());
        assertTrue(invalidFields.isEmpty());

        String invalidIv = configManager.validateIv("abc", "iv", missingFields, invalidFields);
        assertEquals("abc", invalidIv);
        assertTrue(missingFields.isEmpty());
        assertFalse(invalidFields.isEmpty());
    }

    /**
     * Helper method to generate a Base64 encoded encrypted API key with IV appended.
     * @return Base64 encoded encrypted API key
     */
    private String generateBase64EncodedEncryptedApiKey() {
        byte[] iv = "abcdefghijkl".getBytes();
        byte[] cipherText = "ciphertext".getBytes(); // Simulating the ciphertext
        byte[] combined = new byte[iv.length + cipherText.length];

        System.arraycopy(iv, 0, combined, 0, iv.length);
        System.arraycopy(cipherText, 0, combined, iv.length, cipherText.length);

        return Base64.getEncoder().encodeToString(combined);
    }
}
