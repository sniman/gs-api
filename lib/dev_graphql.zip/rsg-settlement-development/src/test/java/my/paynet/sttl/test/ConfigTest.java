package my.paynet.sttl.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalTime;
import java.util.Map;

import org.ini4j.Ini;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import my.paynet.crypto.AESEncryptor;
import my.paynet.sttl.config.Config;

@ExtendWith(MockitoExtension.class)
public class ConfigTest {

    @InjectMocks
    private Config config;

    @Mock
    private Ini.Section section;

    @BeforeEach
    public void setUp() {
        config = new Config();
    }
//
//    @Test
//    public void testSetAndGetGraphqlApiKey() throws Exception {
//        String encryptedApiKey = "encryptedApiKey";
//        String keyPath = "path/to/keyfile";
//        String initVector = "initializati";
//        
//        AESEncryptor decryptor = mock(AESEncryptor.class);
//        when(decryptor.decrypt(any(byte[].class))).thenReturn("decryptedApiKey".getBytes());
//
//        config.setGraphqlApiKey(encryptedApiKey, keyPath, initVector);
//        
//        assertEquals("decryptedApiKey", config.getGraphqlApiKey());
//    }

    @Test
    public void testSetAndGetGraphqlUrl() {
        String graphqlUrl = "http://example.com/graphql";
        config.setGraphqlUrl(graphqlUrl);
        assertEquals(graphqlUrl, config.getGraphqlUrl());
    }

    @Test
    public void testSetAndGetGraphqlSchemaFile() {
        String schemaFile = "schema.graphql";
        config.setGraphqlSchemaFile(schemaFile);
        assertEquals(schemaFile, config.getGraphqlSchemaFile());
    }

    @Test
    public void testSetAndGetGraphqlQueryFile() {
        String queryFile = "query.graphql";
        config.setGraphqlQueryFile(queryFile);
        assertEquals(queryFile, config.getGraphqlQueryFile());
    }

    @Test
    public void testSetAndGetKeyfile() {
        String keyfile = "path/to/keyfile";
        config.setKeyfile(keyfile);
        assertEquals(keyfile, config.getKeyfile());
    }

    @Test
    public void testSetAndGetConnectTimeout() {
        int timeout = 30;
        config.setConnectTimeout(timeout);
        assertEquals(timeout, config.getConnectTimeout());
    }

    @Test
    public void testSetAndGetReadTimeout() {
        int timeout = 30;
        config.setReadTimeout(timeout);
        assertEquals(timeout, config.getReadTimeout());
    }

    @Test
    public void testSetAndGetIv() {
        String iv = "initializationVector";
        config.setIv(iv);
        assertEquals(iv, config.getIv());
    }

    @Test
    public void testSetAndGetWindow1StartTime() {
        String timeString = "08:00:00";
        config.setWindow1StartTime(timeString);
        assertEquals(LocalTime.of(8, 0, 0), config.getWindow1StartTime());
    }

    @Test
    public void testSetAndGetWindow2StartTime() {
        String timeString = "10:00:00";
        config.setWindow2StartTime(timeString);
        assertEquals(LocalTime.of(10, 0, 0), config.getWindow2StartTime());
    }

    @Test
    public void testSetAndGetWindow1EndTime() {
        String timeString = "18:00:00";
        config.setWindow1EndTime(timeString);
        assertEquals(LocalTime.of(18, 0, 0), config.getWindow1EndTime());
    }

    @Test
    public void testSetAndGetWindow2EndTime() {
        String timeString = "20:00:00";
        config.setWindow2EndTime(timeString);
        assertEquals(LocalTime.of(20, 0, 0), config.getWindow2EndTime());
    }

    @Test
    public void testSetAndGetDestPath() {
        String destPath = "path/to/dest";
        config.setDestPath(destPath);
        assertEquals(destPath, config.getDestPath());
    }

    @Test
    public void testSetAndGetArchivePath() {
        String archivePath = "path/to/archive";
        config.setArchivePath(archivePath);
        assertEquals(archivePath, config.getArchivePath());
    }

    @Test
    public void testSetAndGetProduct() {
        String product = "MyProduct";
        config.setProduct(product);
        assertEquals(product, config.getProduct());
    }

    @Test
    public void testSetHolidays() {
        when(section.entrySet()).thenReturn(Map.of("2024-12-25", "Christmas").entrySet());
        config.setHolidays(section);
        assertTrue(config.isHoliday("2024-12-25"));
    }

    @Test
    public void testIsHoliday() {
        config.setHolidays(section);
        assertFalse(config.isHoliday("2024-01-01"));
    }
}
