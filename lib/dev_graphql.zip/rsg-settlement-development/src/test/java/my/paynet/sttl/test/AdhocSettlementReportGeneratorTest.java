package my.paynet.sttl.test;

import my.paynet.sttl.config.Config;
import my.paynet.sttl.config.ConfigManager;
import my.paynet.sttl.scheduler.SlidingWindowScheduler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import my.paynet.sttl.cli.AdhocSettlementReportGenerator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AdhocSettlementReportGeneratorTest {

    private ConfigManager configManager;
    private SlidingWindowScheduler scheduler;

    @BeforeEach
    public void setUp() {
        configManager = mock(ConfigManager.class);
        scheduler = mock(SlidingWindowScheduler.class);
    }

    @Test
    public void testPromptForIniFilePath() {
        String input = "C:\\Users\\tuan.sauwern\\Documents\\NetBeansProjects\\sttl\\src\\main\\resources\\rsgsttlconfig.ini\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        String iniFilePath = AdhocSettlementReportGenerator.promptForIniFilePath(new java.util.Scanner(System.in));
        assertEquals("C:\\Users\\tuan.sauwern\\Documents\\NetBeansProjects\\sttl\\src\\main\\resources\\rsgsttlconfig.ini", iniFilePath);
    }

    @Test
    public void testPromptForSectionName() {
        String input = "san\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        String sectionName = AdhocSettlementReportGenerator.promptForSectionName(new java.util.Scanner(System.in));
        assertEquals("san", sectionName);
    }

    @Test
    public void testPromptForWindow() {
        String input = "WINDOW-1\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        String window = AdhocSettlementReportGenerator.promptForWindow(new java.util.Scanner(System.in));
        assertEquals("WINDOW-1", window);
    }

    @Test
    public void testPromptForDateTime() {
        String input = "2024-07-24\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        LocalDateTime expectedDateTime = LocalDateTime.parse("2024-07-24T00:00:00", java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
        LocalDateTime dateTime = AdhocSettlementReportGenerator.promptForDateTime(new java.util.Scanner(System.in));
        assertEquals(expectedDateTime, dateTime);
    }

//    @Test
//    public void testLoadConfig() {
//        String iniFilePath = "C:\\Users\\tuan.sauwern\\Documents\\NetBeansProjects\\sttl\\src\\main\\resources\\rsgsttlconfig.ini";
//        String sectionName = "mydebit";
//
//        Config mockConfig = new Config();
//        when(configManager.loadConfiguration(iniFilePath, sectionName)).thenReturn(mockConfig);
//
//        Config config = AdhocSettlementReportGenerator.loadConfig(iniFilePath, sectionName);
//        assertEquals(mockConfig, config);
//    }
}
