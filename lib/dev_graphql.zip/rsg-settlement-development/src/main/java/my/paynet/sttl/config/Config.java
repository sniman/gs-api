/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl.config;

import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import my.paynet.crypto.AESEncryptor;
import my.paynet.util.Utils;
import org.ini4j.Ini;
import org.slf4j.LoggerFactory;

/**
 * Config class handles the configuration settings for the application. It
 * includes methods for setting and getting various configuration parameters
 * such as API keys, URLs, file paths, time windows, and holidays.
 *
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class Config {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(Config.class);
    private String graphqlApiKey;
    private String graphqlUrl;
    private String graphqlSchemaFile;
    private String graphqlQueryFile;
    private String keyfile;
    private int connectTimeout;
    private int readTimeout;
    private String iv;
    private LocalTime window1StartTime;
    private LocalTime window2StartTime;
    private LocalTime window1EndTime;
    private LocalTime window2EndTime;
    private String destPath;
    private String archivePath;
    private String product;
    private static final String TIME_HHMMSS = "HH:mm:ss";
    private final Map<String, String> holidayMap;

    /**
     * Constructs a new Config instance.
     */
    public Config() {
        holidayMap = new HashMap<>();
    }

    /**
     * Sets the holidays from an INI section.
     *
     * @param section the INI section containing the holidays
     */
    public void setHolidays(Ini.Section section) {
        for (Map.Entry<String, String> entry : section.entrySet()) {
            holidayMap.put(entry.getKey(), entry.getValue());
        }
    }

    /**
     * @return the window1EndTime
     */
    public LocalTime getWindow1EndTime() {
        return window1EndTime;
    }

    /**
     * @param window1EndTime the window1EndTime to set
     */
    public void setWindow1EndTime(LocalTime window1EndTime) {
        this.window1EndTime = window1EndTime;
    }

    /**
     * @return the window2EndTime
     */
    public LocalTime getWindow2EndTime() {
        return window2EndTime;
    }

    /**
     * @param window2EndTime the window2EndTime to set
     */
    public void setWindow2EndTime(LocalTime window2EndTime) {
        this.window2EndTime = window2EndTime;
    }

    /**
     * Checks if the given day is a holiday.
     *
     * @param day the day to check
     * @return true if the day is a holiday, false otherwise
     */
    public boolean isHoliday(String day) {
        if (holidayMap.containsKey(day)) {
            logger.info("{} is a holiday for {}.", day, holidayMap.get(day));
            return true;
        } else {
            return false;
        }
    }

    /**
     * @return the product
     */
    public String getProduct() {
        return product;
    }

    /**
     * @param product the product to set
     */
    public void setProduct(String product) {
        this.product = product;
    }

    /**
     * @return the destPath
     */
    public String getDestPath() {
        return destPath;
    }

    /**
     * @param destPath the destPath to set
     */
    public void setDestPath(String destPath) {
        this.destPath = destPath;
    }

    /**
     * @return the archivePath
     */
    public String getArchivePath() {
        return archivePath;
    }

    /**
     * @param archivePath the archivePath to set
     */
    public void setArchivePath(String archivePath) {
        this.archivePath = archivePath;
    }

    /**
     * @return the window1StartTime
     */
    public LocalTime getWindow1StartTime() {
        return window1StartTime;
    }

    /**
     * @return the window2StartTime
     */
    public LocalTime getWindow2StartTime() {
        return window2StartTime;
    }

    /**
     * @return the GraphQL API key
     */
    public String getGraphqlApiKey() {
        return graphqlApiKey;
    }

    /**
     * Sets the window1 end time from a time string.
     *
     * @param timeString the time string in HH:mm:ss format
     */
    public void setWindow1EndTime(String timeString) {
        final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(TIME_HHMMSS);

        try {
            this.setWindow1EndTime(LocalTime.parse(timeString, formatter));
        } catch (DateTimeParseException e) {
            logger.error("Invalid Window1 start time {} {}", timeString, Utils.getStackTraceAsString(e));
            System.exit(2);
        }
    }

    /**
     * Sets the window2 end time from a time string.
     *
     * @param timeString the time string in HH:mm:ss format
     */
    public void setWindow2EndTime(String timeString) {
        final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(TIME_HHMMSS);

        try {
            this.setWindow2EndTime(LocalTime.parse(timeString, formatter));
        } catch (DateTimeParseException e) {
            logger.error("Invalid Window2 start time {} {}", timeString, Utils.getStackTraceAsString(e));
            System.exit(3);
        }
    }

    /**
     * Sets the window1 start time from a time string.
     *
     * @param timeString the time string in HH:mm:ss format
     */
    public void setWindow1StartTime(String timeString) {
        final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(TIME_HHMMSS);

        try {
            this.window1StartTime = LocalTime.parse(timeString, formatter);
        } catch (DateTimeParseException e) {
            logger.error("Invalid Window1 start time {} {}", timeString, Utils.getStackTraceAsString(e));
            System.exit(2);
        }
    }

    /**
     * Sets the window2 start time from a time string.
     *
     * @param timeString the time string in HH:mm:ss format
     */
    public void setWindow2StartTime(String timeString) {
        final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(TIME_HHMMSS);

        try {
            this.window2StartTime = LocalTime.parse(timeString, formatter);
        } catch (DateTimeParseException e) {
            logger.error("Invalid Window2 start time {} {}", timeString, Utils.getStackTraceAsString(e));
            System.exit(3);
        }
    }

    /**
     * Sets the GraphQL API key after decrypting it.
     *
     * @param graphqlApiKey the encrypted GraphQL API key
     * @param keyPath the path to the encryption key file
     * @param initVector the initialization vector
     */
    public void setGraphqlApiKey(String graphqlApiKey, String keyPath, String initVector) {
        AESEncryptor dec = new AESEncryptor(keyPath, initVector);
        dec.init();
        try {
            byte[] decodedKey = Base64.getDecoder().decode(graphqlApiKey.getBytes(StandardCharsets.UTF_8));
            byte[] plainText = dec.decrypt(decodedKey);
            if (plainText.length==0) {
                throw new IllegalArgumentException("Invalid ciphertext length!");
            } else {
                
                this.graphqlApiKey = new String(plainText, StandardCharsets.UTF_8);
            }
        } catch (IllegalBlockSizeException | BadPaddingException | InvalidKeyException | InvalidAlgorithmParameterException | NoSuchAlgorithmException | NoSuchPaddingException ex) {
            logger.error(Utils.getStackTraceAsString(ex));
        }
    }

    /**
     * @return the GraphQL URL
     */
    public String getGraphqlUrl() {
        return graphqlUrl;
    }

    /**
     * Sets the GraphQL URL.
     *
     * @param graphqlUrl the GraphQL URL to set
     */
    public void setGraphqlUrl(String graphqlUrl) {
        this.graphqlUrl = graphqlUrl;
    }

    /**
     * @return the GraphQL schema file path
     */
    public String getGraphqlSchemaFile() {
        return graphqlSchemaFile;
    }

    /**
     * Sets the GraphQL schema file path.
     *
     * @param graphqlSchemaFile the GraphQL schema file path to set
     */
    public void setGraphqlSchemaFile(String graphqlSchemaFile) {
        this.graphqlSchemaFile = graphqlSchemaFile;
    }

    /**
     * @return the GraphQL query file path
     */
    public String getGraphqlQueryFile() {
        return graphqlQueryFile;
    }

    /**
     * Sets the GraphQL query file path.
     *
     * @param graphqlQueryFile the GraphQL query file path to set
     */
    public void setGraphqlQueryFile(String graphqlQueryFile) {
        this.graphqlQueryFile = graphqlQueryFile;
    }

    /**
     * @return the key file path
     */
    public String getKeyfile() {
        return keyfile;
    }

    /**
     * Sets the key file path.
     *
     * @param keyfile the key file path to set
     */
    public void setKeyfile(String keyfile) {
        this.keyfile = keyfile;
    }

    /**
     * @return the connection timeout in seconds
     */
    public int getConnectTimeout() {
        return connectTimeout;
    }

    /**
     * Sets the connection timeout in seconds.
     *
     * @param connectTimeout the connection timeout to set
     */
    public void setConnectTimeout(int connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    /**
     * @return the read timeout in seconds
     */
    public int getReadTimeout() {
        return readTimeout;
    }

    /**
     * Sets the read timeout in seconds.
     *
     * @param readTimeout the read timeout to set
     */
    public void setReadTimeout(int readTimeout) {
        this.readTimeout = readTimeout;
    }

    /**
     * @return the initialization vector (IV)
     */
    public String getIv() {
        return iv;
    }

    /**
     * Sets the initialization vector (IV).
     *
     * @param iv the initialization vector to set
     */
    public void setIv(String iv) {
        this.iv = iv;
    }
}
