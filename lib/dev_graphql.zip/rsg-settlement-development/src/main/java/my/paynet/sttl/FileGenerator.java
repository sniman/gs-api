/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import my.paynet.sttl.config.Config;
import my.paynet.sttl.model.Entry;
import my.paynet.sttl.model.RentasData;
import my.paynet.sttl.model.Response;
import my.paynet.sttl.scheduler.SlidingWindowScheduler;
import my.paynet.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class FileGenerator {

    private static final Logger logger = LoggerFactory.getLogger(FileGenerator.class);
    private Config config;
    private String window;
    private LocalDateTime reportTime;

    public FileGenerator(Config conf, LocalDateTime ldt, String win) {

        this.config = conf;
        this.window = win;
        this.reportTime = ldt;
    }

    public void generateHashFile(String fileName, String val) {

        // Get a MessageDigest instance for SHA-256
        MessageDigest digest;
        String fullPath =  this.config.getDestPath() + File.separator +fileName;
        try (BufferedWriter writer = Files.newBufferedWriter(Path.of(fullPath), StandardCharsets.UTF_8)) {
            digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(val.getBytes(StandardCharsets.UTF_8));
            String hexValues = Utils.hexNoSpace(hash);
            // Write the line to the file
            writer.write(hexValues);
            writer.newLine();
            logger.info("File {} Line {} written to file successfully.",fullPath, hexValues);

        } catch (NoSuchAlgorithmException ex) {
            logger.error(Utils.getStackTraceAsString(ex));
        } catch (IOException e) {
            logger.info("Failed to write to file: " + e.getMessage());
        }

        // Calculate the checksum
    }

    public void generateFile(Response resp) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yy-MM-dd");
        String formattedDate = this.reportTime.format(formatter);
        String[] dateComponents = formattedDate.split("-");
        String month = getMonth(dateComponents[1]);

        String batchNum = "";
        //check whether it is weekend?
        if (this.window.equals(SlidingWindowScheduler.WINDOW1)) {
            batchNum = "20"; //Window 1 is always 20
        } else if (this.window.equals(SlidingWindowScheduler.WINDOW2)) {
            if (this.config.isHoliday("20" + formattedDate) || isWeekend(this.reportTime)) {
                batchNum = "30"; //some silly handling to tag public holiday as 30
            } else {
                batchNum = "10"; //if not a holiday, then 10.
            }
        }
        String fileName = getFileNamePrefix() + dateComponents[0] + month + dateComponents[2] + batchNum + ".TXT";
        String hashFileName = getFileNamePrefix() + dateComponents[0] + month + dateComponents[2] + batchNum + "H.TXT";
        String path = this.config.getDestPath() + File.separator + fileName;
        logger.info("{}: Filename:{}", this.window, path);
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(path))) {
            RentasData d = null;

            switch (this.config.getProduct()) {
                case Product.MYDEBIT ->
                    d = resp.getData().getMyDebit().getRentas().getData();
                case Product.SAN ->
                    d = resp.getData().getSAN().getRentas().getData();
                default -> {
                    logger.error("Invalid Product {}", this.config.getProduct());
                    throw new IllegalArgumentException("Invalid product " + this.config.getProduct());
                }
            }

            //write records
            List<Entry> entries = d.getEntries();
            StringBuilder forHash = new StringBuilder();
            for (Entry entry : entries) {
                writer.write(entry.toReportEntry());
                forHash.append(path);
                //double check we want CRLF or just CR since different operating system behave differently.
                writer.newLine();
            }

            //write footer
            writer.write(d.getTotal().toReportTotal());
            forHash.append(d.getTotal().toReportTotal());
            writer.newLine();
            //write trailer
            String footer = "T" + d.getChecksum();
            writer.write(footer);
            forHash.append(footer);

            writer.newLine();
            this.generateHashFile(hashFileName, forHash.toString());
        } catch (IOException e) {
            logger.error("{}: Exception while writing to file {}, {}", window, path, Utils.getStackTraceAsString(e));
        }
    }

    public int getMultiplier(String ctdt) {

        if ("CR".equals(ctdt)) {
            return 3;
        } else if ("DR".equals(ctdt)) {
            return 2;
        } else if ("00".equals(ctdt)) {
            return 0;
        } else {
            return -1;
        }
    }

    public String getFileNamePrefix() {
        String prod = this.config.getProduct();
        String prefix = "";
        if (prod.equals(Product.MYDEBIT)) {
            prefix = "C";
        } else if (prod.equals(Product.SAN)) {
            prefix = "A";
        }
        return prefix;
    }

    public String getMonth(String month) {

        String formattedMonth = null;
        switch (month) {
            case "01":
                formattedMonth = "1";
                break;
            case "02":
                formattedMonth = "2";
                break;
            case "03":
                formattedMonth = "3";
                break;
            case "04":
                formattedMonth = "4";
                break;
            case "05":
                formattedMonth = "5";
                break;
            case "06":
                formattedMonth = "6";
                break;
            case "07":
                formattedMonth = "7";
                break;
            case "08":
                formattedMonth = "8";
                break;
            case "09":
                formattedMonth = "9";
                break;
            case "10":
                formattedMonth = "A";
                break;
            case "11":
                formattedMonth = "B";
                break;
            case "12":
                formattedMonth = "C";
                break;
            default:
                break;
        }
        return formattedMonth;
    }

    /**
     * Checks if the given LocalDateTime is a weekend.
     *
     * @param dateTime the LocalDateTime to check
     * @return true if the date is a weekend, false otherwise
     */
    public boolean isWeekend(LocalDateTime dateTime) {
        DayOfWeek dayOfWeek = dateTime.getDayOfWeek();
        return dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY;
    }
}
