/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl.scheduler;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import my.paynet.sttl.FileGenerator;
import my.paynet.sttl.config.Config;
import my.paynet.sttl.graphql.GraphQLClient;
import my.paynet.sttl.model.Response;
import my.paynet.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A scheduler that manages tasks based on sliding windows. It schedules and
 * retries tasks within specified time windows.
 * <p>
 * This scheduler handles two time windows defined by {@link #window1StartTime}, {@link #window1EndTime},
 * {@link #window2StartTime}, and {@link #window2EndTime}. It also manages task
 * retries with exponential backoff and status reporting at fixed intervals.
 * </p>
 *
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class SlidingWindowScheduler {

    private static final Logger logger = LoggerFactory.getLogger(SlidingWindowScheduler.class);
    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(3);

    // Purposely not setting these fields final because the long-term goal is to enable this program to be reloadable.
    private LocalTime window2StartTime;
    private LocalTime window1StartTime;
    private LocalTime window2EndTime;
    private LocalTime window1EndTime;

    public static final String WINDOW1 = "WINDOW-1";
    public static final String WINDOW2 = "WINDOW-2";

    // Purposely not setting this attribute to final
    private Config config;
    private LocalDateTime lastWindow1Success;
    private LocalDateTime lastWindow2Success;

    private LocalDateTime lastWindow1Failure = null;
    private LocalDateTime nextWindow1Execution = null;

    private LocalDateTime lastWindow2Failure = null;
    private LocalDateTime nextWindow2Execution = null;

    /**
     * Constructs a new SlidingWindowScheduler with the specified configuration.
     *
     * @param conf the configuration object containing the time windows and
     * other settings
     */
    public SlidingWindowScheduler(Config conf) {
        this.config = conf;
        this.window2StartTime = conf.getWindow2StartTime();
        this.window1StartTime = conf.getWindow1StartTime();
        this.window2EndTime = conf.getWindow2EndTime();
        this.window1EndTime = conf.getWindow1EndTime();
    }

    /**
     * Schedules a task to run within the specified window.
     *
     * @param window the name of the window (WINDOW-1 or WINDOW-2)
     */
    public void scheduleWindow(String window) {
        logger.info("{}: Calculating initial delay", window);
        long initialDelay = calculateInitialDelay(window);
        logger.info("{}: Scheduling to run after {}s", window, initialDelay);
        if (initialDelay == 0) {
            retryTask(window);
        } else {
            LocalDateTime nxtRun = LocalDateTime.now().plusSeconds(initialDelay);
            logger.info("{}: Scheduling to run after initial delay of {}s at {}", window, initialDelay, nxtRun);
            if (WINDOW1.equals(window)) {
                this.nextWindow1Execution = nxtRun;
            } else {
                this.nextWindow2Execution = nxtRun;
            }
            getScheduler().schedule(() -> retryTask(window), initialDelay, TimeUnit.SECONDS);
        }
    }

    /**
     * Calculates the initial delay before the task should run based on the
     * current time and the specified window.
     *
     * @param windowName the name of the window (WINDOW-1 or WINDOW-2)
     * @return the delay in seconds before the task should run
     */
    public long calculateInitialDelay(String windowName) {

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime startDateTime = this.getStartDateTime(now, windowName);
        LocalDateTime endDateTime = this.getEndDateTime(now, windowName);

        if (now.isAfter(startDateTime) && now.isBefore(endDateTime)) {
            now = now.plusSeconds(1);
            if ((WINDOW1.equals(windowName) && this.lastWindow1Success == null)
                    || (WINDOW2.equals(windowName) && this.lastWindow2Success == null)) {
                logger.info("{}: Task is being performed immediately as it falls within the window {}.", windowName);
                return 0;
            } else if (WINDOW1.equals(windowName) && now.isAfter(this.lastWindow1Success)) {
                logger.info("{}: Previous successful run for window1 was {} ", WINDOW1, this.lastWindow1Success);
                now = now.minusSeconds(1);
            } else if (WINDOW2.equals(windowName) && now.isAfter(this.lastWindow2Success)) {
                logger.info("{}: Previous successful run for window2 was {} ", WINDOW2, this.lastWindow2Success);
                now = now.minusSeconds(1);
            } else {
                logger.info("{}: Task is being performed immediately (abnormal) as it falls within the window {}.", windowName);
                return 0; // No delay, task should run immediately
            }
        }

        if (now.isAfter(startDateTime)) {
            startDateTime = startDateTime.plusDays(1);
        }
        return ChronoUnit.SECONDS.between(now, startDateTime);
    }

    /**
     * Returns the start time for the specified window as a LocalDateTime.
     *
     * @param now the current LocalDateTime
     * @param windowName the name of the window (WINDOW-1 or WINDOW-2)
     * @return the start time for the window as a LocalDateTime
     */
    public LocalDateTime getStartDateTime(LocalDateTime now, String windowName) {
        LocalTime startTime = windowName.equals(WINDOW1) ? window1StartTime : window2StartTime;
        return now.withHour(startTime.getHour())
                .withMinute(startTime.getMinute())
                .withSecond(startTime.getSecond())
                .withNano(0);
    }

    /**
     * Returns the end time for the specified window as a LocalDateTime.
     *
     * @param now the current LocalDateTime
     * @param windowName the name of the window (WINDOW-1 or WINDOW-2)
     * @return the end time for the window as a LocalDateTime
     */
    public LocalDateTime getEndDateTime(LocalDateTime now, String windowName) {
        LocalTime endTime = windowName.equals(WINDOW1) ? window1EndTime : window2EndTime;
        return now.withHour(endTime.getHour())
                .withMinute(endTime.getMinute())
                .withSecond(endTime.getSecond())
                .withNano(0);
    }

    /**
     * Retries the task with exponential backoff until it succeeds or until a
     * certain condition is met.
     *
     * @param windowName the name of the window (WINDOW-1 or WINDOW-2)
     */
    private void retryTask(String windowName) {

        RetryTask task = new RetryTask(windowName);
        getScheduler().submit(task);
    }

    /**
     * Performs the actual task.
     *
     * @param windowName the name of the window (WINDOW-1 or WINDOW-2)
     * @param currentTime the current LocalDateTime when the task is performed
     * @return true if the task was successful, false otherwise
     * @throws IOException if an I/O error occurs
     * @throws ParseException if a parsing error occurs
     * @throws org.apache.hc.core5.http.ParseException if a HTTP parsing error
     * occurs
     * @throws URISyntaxException if a URI syntax error occurs
     */
    public boolean performTask(String windowName, LocalDateTime currentTime) throws IOException, ParseException, org.apache.hc.core5.http.ParseException, URISyntaxException {
        logger.info("{}: Executing Task... for {}", windowName, config.getProduct());
        GraphQLClient client = new GraphQLClient(config);
        try {
            Response resp = client.query(windowName, currentTime);
            if (resp == null) {
                throw new IOException(windowName + ": Invalid response.");
            } else {
                FileGenerator fg = new FileGenerator(this.config, currentTime, windowName);
                fg.generateFile(resp);
            }
        } catch (IOException | URISyntaxException | ParseException | org.apache.hc.core5.http.ParseException ex) {
            logger.error("{} {} ", this.config.getProduct(), windowName, Utils.getStackTraceAsString(ex));
            throw ex;
        }
        logger.info("{}: Task completed successfully.", windowName);
        return true;
    }

    /**
     * Reports the status of the last failed and next scheduled jobs.
     */
    public void reportStatus() {
        logger.info("\n===>{}: Last Success Job [{}], Last Failed Job [{}], Next Job [{}]\n===>{}: Last Success Job [{}], Last Failed Job [{}], Next Job [{}]",
                WINDOW1, this.lastWindow1Success, this.lastWindow1Failure, this.nextWindow1Execution,
                WINDOW2, this.lastWindow2Success, this.lastWindow2Failure, this.nextWindow2Execution);
    }

    /**
     * Schedules the status report to run at fixed intervals.
     */
    public void scheduleReportStatus() {
        getScheduler().scheduleAtFixedRate(this::reportStatus, 0, 1, TimeUnit.MINUTES);
    }

    /**
     * Shuts down the scheduler gracefully.
     */
    public void shutdown() {
        logger.info("Shutdown signal received. Initiating graceful shutdown...");
        getScheduler().shutdown();
        try {
            if (!scheduler.awaitTermination(60, TimeUnit.SECONDS)) {
                logger.warn("Scheduler did not terminate in the specified time.");
                getScheduler().shutdownNow();
                if (!scheduler.awaitTermination(60, TimeUnit.SECONDS)) {
                    logger.error("Scheduler did not terminate.");
                }
            }
        } catch (InterruptedException e) {
            logger.error("Shutdown interrupted: {}", Utils.getStackTraceAsString(e));
            getScheduler().shutdownNow();
            Thread.currentThread().interrupt();
        }
        logger.info("Scheduler shutdown complete.");
    }

    /**
     * Inner class that represents a retryable task for a specific window.
     */
    class RetryTask implements Runnable {

        private static final Logger logger = LoggerFactory.getLogger(RetryTask.class);
        private final String windowName;
        
        private int attempt=1;
        private long delay=1; 

        /**
         * Constructs a new RetryTask for the specified window.
         *
         * @param windowName the name of the window (WINDOW-1 or WINDOW-2)
         */
        public RetryTask(String windowName) {
            this.windowName = windowName;
        }

        @Override
        public void run() {
            LocalDateTime firstFailureTime = null;
            delay=1;
            attempt=1;
            while (true) {
                try {
                    if (isTaskOK()) {
                        break;
                    }
                    setLastFailureTime(windowName);
                } catch (Exception e) {
                    logger.error("Exception in {} Task: {}", windowName, Utils.getStackTraceAsString(e));
                    setLastFailureTime(windowName);
                    firstFailureTime = updateFirstFailureTime(firstFailureTime);
                    updateDelayAndAttempt(firstFailureTime);
                    triggerDelay(windowName, delay);
                }
            }
            scheduleNextWindow(windowName);
        }

        /**
         * Executes the task.
         *
         * @return true if the task was successful, false otherwise
         * @throws Exception if an error occurs during task execution
         */
        private boolean isTaskOK() throws Exception {
            LocalDateTime currentTime = LocalDateTime.now();
            logger.info("{}: Task triggered at: {}", windowName, currentTime);
            return performTask(windowName, currentTime);
        }

        /**
         * Updates the first failure time if it is null.
         *
         * @param firstFailureTime the current first failure time
         * @return the updated first failure time
         */
        private LocalDateTime updateFirstFailureTime(LocalDateTime firstFailureTime) {
            if (firstFailureTime == null) {
                logger.info("{}: First time failed.", windowName);
                return LocalDateTime.now();
            }
            return firstFailureTime;
        }

        /**
         * Updates the delay and attempt count based on the time since the first
         * failure.
         *
         * @param firstFailureTime the first failure time
         */
        private void updateDelayAndAttempt(LocalDateTime firstFailureTime) {
            long minutesSinceFirstFailure = ChronoUnit.MINUTES.between(firstFailureTime, LocalDateTime.now());
            if (minutesSinceFirstFailure > 30) {
                logger.info("Minutes since first failure {} exceeds 30 ",minutesSinceFirstFailure);
                resetDelayAndAttempt(minutesSinceFirstFailure);
            } else {
                delay = delay * (1 << (attempt - 1));
                attempt++;
                logger.info("Exponentially increased delay {}s",delay);
            }
            if (delay > TimeUnit.MINUTES.toSeconds(30)) {
                logger.info("Delay {}s more than 30 minutes.",delay);
                resetDelayAndAttempt(minutesSinceFirstFailure);
            }
        }

        /**
         * Resets the delay and attempt count.
         *
         * @param minutesSinceFirstFailure the time in minutes since the first
         * failure
         */
        private void resetDelayAndAttempt(long minutesSinceFirstFailure) {
            delay = 5;
            attempt = 1;
            logger.info("{}: Minutes since first failure {} mins. Resetting attempts to 1.", windowName, minutesSinceFirstFailure);
        }

        /**
         * Schedules the next window based on the success of the current window.
         *
         * @param windowName the name of the window (WINDOW-1 or WINDOW-2)
         */
        private void scheduleNextWindow(String windowName) {

            if (WINDOW1.equals(windowName)) {
                lastWindow1Success = LocalDateTime.now();
                scheduleWindow(WINDOW1);
            } else if (WINDOW2.equals(windowName)) {
                lastWindow2Success = LocalDateTime.now();
                scheduleWindow(WINDOW2);
            }
        }

        /**
         * Triggers a delay before the next attempt.
         *
         * @param windowName the name of the window (WINDOW-1 or WINDOW-2)
         * @param delay the delay in seconds
         * @param attempt the current attempt count
         */
        private void triggerDelay(String windowName, long delay) {

            try {
                logger.info("{}: Delaying for {}s for attempt {}", windowName, delay, attempt);
                TimeUnit.SECONDS.sleep(delay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                logger.info(Utils.getStackTraceAsString(e));
            }
        }

        /**
         * Sets the last failure time for the specified window.
         *
         * @param windowName the name of the window (WINDOW-1 or WINDOW-2)
         */
        private void setLastFailureTime(String windowName) {

            if (WINDOW1.equals(windowName)) {
                lastWindow1Failure = LocalDateTime.now();
            } else if (WINDOW2.equals(windowName)) {
                lastWindow2Failure = LocalDateTime.now();
            }

        }
    }

    /**
     * @return the scheduler
     */
    public ScheduledExecutorService getScheduler() {
        return scheduler;
    }

    /**
     * @param scheduler the scheduler to set
     */
    public void setScheduler(ScheduledExecutorService scheduler) {
        this.scheduler = scheduler;
    }
}
