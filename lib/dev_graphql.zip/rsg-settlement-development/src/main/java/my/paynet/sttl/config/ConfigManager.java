/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl.config;

import org.ini4j.Ini;
import org.ini4j.InvalidFileFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import my.paynet.sttl.Product;
import my.paynet.util.Utils;

/**
 * ConfigManager handles the loading and validation of configuration from an INI file.
 * 
 * <p>This class reads configuration from an INI file, validates the configuration values,
 * and sets the values to a {@link Config} object. It also handles the validation of various
 * fields like URLs, file paths, time formats, etc.</p>
 *
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class ConfigManager {

    private Config config;
    private static final Logger logger = LoggerFactory.getLogger(ConfigManager.class);
    private static final String TIME_24_HOUR_PATTERN = "^([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)$";
    private static final String GRAPHQL_URL = "graphql_url";
    private static final String GRAPHQL_SCHEMA_FILE = "graphql_schema_file";
    private static final String GRAPHQL_QUERY_FILE = "graphql_query_file";
    private static final String KEYFILE = "keyfile";
    private static final String CONNECT_TIMEOUT = "connect_timeout";
    private static final String READ_TIMEOUT = "read_timeout";
    private static final String IV = "iv";
    private static final String GRAPHQL_API_KEY = "graphql_api_key";
    private static final String WINDOW2_START_TIME = "window2_start_time";
    private static final String WINDOW1_START_TIME = "window1_start_time";
    private static final String WINDOW2_END_TIME = "window2_end_time";
    private static final String WINDOW1_END_TIME = "window1_end_time";
    private static final String DEST_PATH = "dest_path";
    private static final String ARCHIVE_PATH = "archive_path";
    private static final String PRODUCT = "product";
    private static final String HOLIDAY_SECTION = "holidays";
    private static final Pattern PATTERN24TIME = Pattern.compile(TIME_24_HOUR_PATTERN);
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final String NOB = "Null or Blank";

    /**
     * Constructs a new ConfigManager instance.
     */
    public ConfigManager() {
        config = new Config();
    }

    /**
     * Gets the current configuration.
     *
     * @return the current {@link Config} object
     */
    public Config getConfig() {
        return this.config;
    }

    /**
     * Loads the configuration from the specified INI file and section.
     *
     * @param iniFilePath the path to the INI file
     * @param sectionName the name of the section to load
     * @return the loaded {@link Config} object
     * @throws IllegalArgumentException if the INI file path or section name is invalid, or if required fields are missing or invalid
     */
    public Config loadConfiguration(final String iniFilePath, final String sectionName) {
        logger.info("Environment Variables:");
        logger.info("INI File Path: {}", iniFilePath);
        logger.info("Section Name (Product): {}", sectionName);

        if (iniFilePath == null || iniFilePath.trim().isEmpty()) {
            logger.error("INI file path must be provided via -DiniFilePath");
            throw new IllegalArgumentException("INI file path must be provided via -DiniFilePath");
        }

        if (sectionName == null || sectionName.trim().isEmpty()) {
            logger.error("Section name must be provided via -DsectionName");
            throw new IllegalArgumentException("Section name must be provided via -DsectionName");
        }

        try {
            Ini ini = loadIniFile(iniFilePath);
            Ini.Section section = ini.get(sectionName);

            if (section == null) {
                logger.error("Section '{}' not found in the INI file.", sectionName);
                throw new IllegalArgumentException("Section '" + sectionName + "' not found in the INI file.");
            }

            Ini.Section holsSection = ini.get(HOLIDAY_SECTION);
            if (holsSection == null) {
                logger.error("Section {} is not found in the INI file. Please add it and define the holidays.", HOLIDAY_SECTION);
                throw new IllegalArgumentException("Section '" + HOLIDAY_SECTION + "' is not found in the INI file. Please add it and define the holidays.");
            }

            List<String> missingFields = new ArrayList<>();
            List<String> invalidFields = new ArrayList<>();

            config.setGraphqlUrl(validateUrl(section.get(GRAPHQL_URL), GRAPHQL_URL, missingFields, invalidFields));
            config.setGraphqlSchemaFile(validateFromClasspath(section.get(GRAPHQL_SCHEMA_FILE), GRAPHQL_SCHEMA_FILE, missingFields, invalidFields));
            config.setGraphqlQueryFile(validateFromClasspath(section.get(GRAPHQL_QUERY_FILE), GRAPHQL_QUERY_FILE, missingFields, invalidFields));
            config.setKeyfile(validateFile(section.get(KEYFILE), KEYFILE, missingFields, invalidFields));
            config.setConnectTimeout(validateIntField(section.get(CONNECT_TIMEOUT), CONNECT_TIMEOUT, missingFields, invalidFields));
            config.setReadTimeout(validateIntField(section.get(READ_TIMEOUT), READ_TIMEOUT, missingFields, invalidFields));
            config.setIv(validateIv(section.get(IV), IV, missingFields, invalidFields));
            config.setGraphqlApiKey(getRequiredField(section, GRAPHQL_API_KEY, missingFields), config.getKeyfile(), config.getIv());
            config.setWindow2StartTime(validateTime(section.get(WINDOW2_START_TIME), WINDOW2_START_TIME, missingFields, invalidFields));
            config.setWindow1StartTime(validateTime(section.get(WINDOW1_START_TIME), WINDOW1_START_TIME, missingFields, invalidFields));
            config.setWindow2EndTime(validateTime(section.get(WINDOW2_END_TIME), WINDOW2_END_TIME, missingFields, invalidFields));
            config.setWindow1EndTime(validateTime(section.get(WINDOW1_END_TIME), WINDOW1_END_TIME, missingFields, invalidFields));
            config.setDestPath(validatePath(section.get(DEST_PATH), DEST_PATH, missingFields, invalidFields));
            config.setArchivePath(validatePath(section.get(ARCHIVE_PATH), ARCHIVE_PATH, missingFields, invalidFields));
            config.setProduct(validateProduct(section.get(PRODUCT), PRODUCT, missingFields, invalidFields));
            if (isValidHolidays(holsSection)) {
                config.setHolidays(holsSection);
            }

            logger.info("GraphQL URL: {} {}", GRAPHQL_URL, config.getGraphqlUrl());
            logger.info("GraphQL Schema File: {} {}", GRAPHQL_SCHEMA_FILE, config.getGraphqlSchemaFile());
            logger.info("GraphQL Query File: {} {}", GRAPHQL_QUERY_FILE, config.getGraphqlQueryFile());
            logger.info("Keyfile: {} {}", KEYFILE, config.getKeyfile());
            logger.info("Connect Timeout: {} {}s", CONNECT_TIMEOUT, config.getConnectTimeout());
            logger.info("Read Timeout: {} {}s", READ_TIMEOUT, config.getReadTimeout());
            logger.info("Window2 Start Time: {} {}", WINDOW2_START_TIME, config.getWindow2StartTime());
            logger.info("Window1 Start Time: {} {}", WINDOW1_START_TIME, config.getWindow1StartTime());
            logger.info("Window2 End Time: {} {}", WINDOW2_END_TIME, config.getWindow2EndTime());
            logger.info("Window1 End Time: {} {}", WINDOW1_END_TIME, config.getWindow1EndTime());
            logger.info("Destination Path: {} {}", DEST_PATH, config.getDestPath());
            logger.info("Archive Path: {} {}", ARCHIVE_PATH, config.getArchivePath());
            logger.info("Product: {} {}", PRODUCT, config.getProduct());

            if (!missingFields.isEmpty() || !invalidFields.isEmpty()) {
                if (!missingFields.isEmpty()) {
                    logger.error("Missing required fields: " + String.join(", ", missingFields));
                }
                if (!invalidFields.isEmpty()) {
                    logger.error("Invalid fields: " + String.join(", ", invalidFields));
                }
                throw new IllegalArgumentException("Invalid fields: " + String.join(", ", invalidFields));
            }
        } catch (InvalidFileFormatException e) {
            logger.error("Invalid INI file format: {} ", Utils.getStackTraceAsString(e));
            throw new IllegalArgumentException("Invalid INI file format: " + e.getMessage());
        } catch (IOException e) {
            logger.error("Error reading INI file: {}", Utils.getStackTraceAsString(e));
            throw new IllegalArgumentException("Error reading INI file: " + e.getMessage());
        }
        return config;
    }

    /**
     * Retrieves a required field from the INI section.
     *
     * @param section the INI section
     * @param key the key of the required field
     * @param missingFields the list to collect missing fields
     * @return the value of the required field, or null if missing
     */
    public String getRequiredField(Ini.Section section, String key, List<String> missingFields) {
        String value = section.get(key);
        if (value == null || value.trim().isEmpty()) {
            missingFields.add(key);
        }
        return value;
    }

    /**
     * Validates the holidays section in the INI file.
     *
     * @param sec the holidays section
     * @return true if the holidays section is valid, false otherwise
     */
    public boolean isValidHolidays(Ini.Section sec) {
        for (String key : sec.keySet()) {
            logger.info("Holiday {}:{}", key, sec.get(key));
            try {
                LocalDate.parse(key, dateFormatter);
            } catch (DateTimeParseException e) {
                logger.error(Utils.getStackTraceAsString(e));
                return false;
            }
        }
        return true;
    }

        /**
     * Helper method to load the INI file.
     *
     * @param iniFilePath the path to the INI file
     * @return the loaded {@link Ini} object
     * @throws IOException if an I/O error occurs
     */
    public Ini loadIniFile(String iniFilePath) throws IOException {
        return new Ini(new File(iniFilePath));
    }

    /**
     * Validates a time string against the 24-hour format pattern.
     *
     * @param time the time string to validate
     * @param key the key of the time field
     * @param missingFields the list to collect missing fields
     * @param invalidFields the list to collect invalid fields
     * @return the validated time string
     */
    public String validateTime(String time, String key, List<String> missingFields, List<String> invalidFields) {
        if (time == null || time.trim().isEmpty()) {
            missingFields.add(key);
        } else {
            Matcher matcher = PATTERN24TIME.matcher(time);
            boolean isValidTime = matcher.matches();
            if (!isValidTime) {
                invalidFields.add(key);
            }
        }
        return time;
    }

    /**
     * Validates a URL string.
     *
     * @param url the URL string to validate
     * @param key the key of the URL field
     * @param missingFields the list to collect missing fields
     * @param invalidFields the list to collect invalid fields
     * @return the validated URL string
     */
    public String validateUrl(String url, String key, List<String> missingFields, List<String> invalidFields) {
        if (url == null || url.trim().isEmpty()) {
            missingFields.add(key);
        } else {
            try {
                new URI(url);
            } catch (URISyntaxException e) {
                logger.error("Invalid URI {}",url);
                invalidFields.add(key);
            }
        }
        return url;
    }

    /**
     * Validates a file path from the classpath.
     *
     * @param filePath the file path to validate
     * @param key the key of the file path field
     * @param missingFields the list to collect missing fields
     * @param invalidFields the list to collect invalid fields
     * @return the validated file path string
     */
    public String validateFromClasspath(String filePath, String key, List<String> missingFields, List<String> invalidFields) {
        if (filePath == null || filePath.trim().isEmpty()) {
            missingFields.add(key);
        } else {
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream(filePath);
            if (inputStream == null) {
                invalidFields.add(key);
            }
        }
        return filePath;
    }

    /**
     * Validates a file path.
     *
     * @param filePath the file path to validate
     * @param key the key of the file path field
     * @param missingFields the list to collect missing fields
     * @param invalidFields the list to collect invalid fields
     * @return the validated file path string
     */
    public String validateFile(String filePath, String key, List<String> missingFields, List<String> invalidFields) {
        if (filePath == null || filePath.trim().isEmpty()) {
            missingFields.add(key);
        } else {
            File file = new File(filePath);
            if (!file.exists() || file.isDirectory()) {
                invalidFields.add(key);
            }
        }
        return filePath;
    }

    /**
     * Validates an integer field.
     *
     * @param value the integer field value to validate
     * @param key the key of the integer field
     * @param missingFields the list to collect missing fields
     * @param invalidFields the list to collect invalid fields
     * @return the validated integer value
     */
    public int validateIntField(String value, String key, List<String> missingFields, List<String> invalidFields) {
        if (value == null || value.trim().isEmpty()) {
            missingFields.add(key);
            return 0; // Default value if missing (will not be used due to the check above)
        }
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            invalidFields.add(key);
            return 0; // Default value if invalid (will not be used due to the check above)
        }
    }

    /**
     * Validates a product string.
     *
     * @param value the product value to validate
     * @param key the key of the product field
     * @param missingFields the list to collect missing fields
     * @param invalidFields the list to collect invalid fields
     * @return the validated product value
     */
    public String validateProduct(String value, String key, List<String> missingFields, List<String> invalidFields) {
        if (value == null || value.trim().isEmpty()) {
            missingFields.add(key);
            return NOB;
        }

        if (!value.equals(Product.SAN) && !value.equals(Product.MYDEBIT)) {
            invalidFields.add(key);
        }
        return value;
    }

    /**
     * Validates a file path string.
     *
     * @param pathString the path string to validate
     * @param key the key of the path field
     * @param missingFields the list to collect missing fields
     * @param invalidFields the list to collect invalid fields
     * @return the validated path string
     */
    public String validatePath(String pathString, String key, List<String> missingFields, List<String> invalidFields) {
        if (pathString == null || pathString.trim().isEmpty()) {
            missingFields.add(key);
            return NOB;
        } else {
            String os = System.getProperty("os.name").toLowerCase();
            if (os.contains("win")) {
                String windowsPath = Paths.get(pathString).toString().replace("/", "\\");
                boolean isValidWindowsPath = checkPath(windowsPath, "Windows");
                if (!isValidWindowsPath) {
                    invalidFields.add(key);
                }
            } else if (os.contains("nix") || os.contains("nux") || os.contains("mac")) {
                String linuxPath = Paths.get(pathString).toString().replace("\\", "/");
                boolean isValidLinuxPath = checkPath(linuxPath, "Linux/Mac");
                if (!isValidLinuxPath) {
                    invalidFields.add(key);
                }
            } else {
                logger.error("Unsupported operating system: " + os);
                invalidFields.add(key);
            }
        }
        return pathString;
    }

    /**
     * Checks if the specified path is valid.
     *
     * @param path the path to check
     * @param osType the operating system type (Windows, Linux/Mac)
     * @return true if the path is valid, false otherwise
     */
    public boolean checkPath(String path, String osType) {
        File file = new File(path);
        if (file.exists()) {
            logger.info("{} Path: {} exists.", osType, path);
            if (file.canWrite()) {
                logger.info("{} Path: {} is writable.", osType, path);
                return true;
            } else {
                logger.error("{} Path: {} is not writable.", osType, path);
                return false;
            }
        } else {
            logger.error("{} Path: {} does not exist.", osType, path);
            return false;
        }
    }

    /**
     * Validates an initialization vector (IV).
     *
     * @param iv the IV to validate
     * @param key the key of the IV field
     * @param missingFields the list to collect missing fields
     * @param invalidFields the list to collect invalid fields
     * @return the validated IV string
     */
    public String validateIv(String iv, String key, List<String> missingFields, List<String> invalidFields) {
        if (iv == null || iv.trim().isEmpty()) {
            missingFields.add(key);
        } else if (iv.length() != 12) { // Assuming IV should be 12 characters long
            invalidFields.add(key);
        }
        return iv;
    }
}
