/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Data {

    @JsonProperty("MyDebit")
    private MyDebit myDebit;

    @JsonProperty("SAN")
    private SAN san;

    // Getters and Setters
    public MyDebit getMyDebit() {
        return myDebit;
    }

    public void setMyDebit(MyDebit myDebit) {
        this.myDebit = myDebit;
    }

    // Getters and Setters
    public SAN getSAN() {
        return san;
    }

    public void setSAN(SAN san) {
        this.san = san;
    }
}
