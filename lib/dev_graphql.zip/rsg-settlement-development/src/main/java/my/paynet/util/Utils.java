/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.util;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class Utils {

    private static final String YYYYMMDD = "yyyy-MM-dd";

    private Utils() {

    }

    public static String getStackTraceAsString(Throwable t) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        PrintWriter writer = new PrintWriter(bytes, true);
        t.printStackTrace(writer);
        return bytes.toString();
    }

    public static String hexNoSpace(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte aByte : bytes) {
            result.append(String.format("%02x", aByte));
        }
        return result.toString();
    }

    public static String hex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte aByte : bytes) {
            result.append(String.format("%02x ", aByte));
        }
        return result.toString();
    }

    public static String getDate(LocalDateTime ldt, int days) {
        ldt = ldt.plusDays(days);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(YYYYMMDD);
        return ldt.format(formatter);
    }

    public static String getCurrentDate(int day) {

        LocalDate currentDate = LocalDate.now();
        currentDate = currentDate.plusDays(day);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(YYYYMMDD);
        return currentDate.format(formatter);
    }

    public static String getCurrentDate() {

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(YYYYMMDD);
        return currentDate.format(formatter);
    }

    /**
     * Pads the given string with leading zeros to the specified length.
     *
     * @param input the input string
     * @param length the desired length of the output string
     * @return the input string padded with leading zeros
     */
    public static String padLeadingZeros(String input, int length) {
        if (input == null) {
            input = "";
        }
        int paddingLength = length - input.length();
        if (paddingLength > 0) {
            String padding = IntStream.range(0, paddingLength)
                    .mapToObj(i -> "0")
                    .collect(Collectors.joining());
            return padding + input;
        }
        return input;
    }

    /**
     * Pads the given string with trailing zeros to the specified length.
     *
     * @param input the input string
     * @param length the desired length of the output string
     * @return the input string padded with trailing zeros
     */
    public static String padTrailingZeros(String input, int length) {
        if (input == null) {
            input = "";
        }
        int paddingLength = length - input.length();
        if (paddingLength > 0) {
            String padding = IntStream.range(0, paddingLength)
                    .mapToObj(i -> "0")
                    .collect(Collectors.joining());
            return input + padding;
        }
        return input;
    }

    /**
     * Pads the given string with leading spaces to the specified length.
     *
     * @param input the input string
     * @param length the desired length of the output string
     * @return the input string padded with leading spaces
     */
    public static String padLeadingSpaces(String input, int length) {
        if (input == null) {
            input = "";
        }
        int paddingLength = length - input.length();
        if (paddingLength > 0) {
            String padding = IntStream.range(0, paddingLength)
                    .mapToObj(i -> " ")
                    .collect(Collectors.joining());
            return padding + input;
        }
        return input;
    }

    /**
     * Pads the given string with trailing spaces to the specified length.
     *
     * @param input the input string
     * @param length the desired length of the output string
     * @return the input string padded with trailing spaces
     */
    public static String padTrailingSpaces(String input, int length) {
        if (input == null) {
            input = "";
        }
        int paddingLength = length - input.length();
        if (paddingLength > 0) {
            String padding = IntStream.range(0, paddingLength)
                    .mapToObj(i -> " ")
                    .collect(Collectors.joining());
            return input + padding;
        }
        return input;
    }

}
