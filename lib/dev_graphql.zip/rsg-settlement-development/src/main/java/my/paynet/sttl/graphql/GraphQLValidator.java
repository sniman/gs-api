/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */

package my.paynet.sttl.graphql;

import com.fasterxml.jackson.databind.JsonNode;
import graphql.language.ObjectTypeDefinition;
import graphql.language.TypeName;
import graphql.schema.GraphQLNamedType;
import graphql.schema.GraphQLObjectType;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class for validating GraphQL responses against a schema.
 * <p>
 * This class provides methods to load a GraphQL schema, validate JSON responses against the schema,
 * and log the validation results.
 * </p>
 * 
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class GraphQLValidator {

    private static final Logger logger = LoggerFactory.getLogger(GraphQLValidator.class);

    /**
     * Private constructor to prevent instantiation.
     */
    private GraphQLValidator() {

    }

    /**
     * Loads a GraphQL schema from the specified file path.
     *
     * @param schemaFilePath the path to the schema file
     * @return the loaded GraphQL schema
     * @throws IOException if an I/O error occurs while reading the schema file
     */
    public static GraphQLSchema loadSchema(String schemaFilePath) throws IOException {
        ClassLoader classLoader = GraphQLValidator.class.getClassLoader();
        try (InputStream inputStream = classLoader.getResourceAsStream(schemaFilePath)) {
            if (inputStream == null) {
                throw new IOException("Schema file not found: " + schemaFilePath);
            }
            String schemaContent = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
            SchemaParser schemaParser = new SchemaParser();
            TypeDefinitionRegistry typeRegistry = schemaParser.parse(schemaContent);
            RuntimeWiring runtimeWiring = RuntimeWiring.newRuntimeWiring()
                    .scalar(CustomScalars.limitedString)
                    .scalar(CustomScalars.numericString)
                    .scalar(CustomScalars.date).build();

            SchemaGenerator schemaGenerator = new SchemaGenerator();
            return schemaGenerator.makeExecutableSchema(typeRegistry, runtimeWiring);
        }
    }

    /**
     * Validates a JSON response against a GraphQL schema.
     *
     * @param schemaFilePath the path to the schema file
     * @param response the JSON response to validate
     * @throws IOException if an I/O error occurs while loading the schema or validating the response
     */
    public static boolean validateResponse(String schemaFilePath, JsonNode response) throws IOException {
        GraphQLSchema schema = loadSchema(schemaFilePath);

        JsonNode dataNode = response.get("data");

        if (dataNode == null) {
            logger.error("Response does not contain 'data' field");
            return false;
        }

        // Validate the response data against the schema
        if (validateAgainstSchema(schema, dataNode)) {
            logger.info("Response is valid against the schema.");
            return true;
        } else {
            logger.error("Response is invalid against the schema.");
            return false;
        }
    }

    /**
     * Validates the JSON data node against the GraphQL schema.
     *
     * @param schema the GraphQL schema
     * @param dataNode the JSON data node to validate
     * @return true if the data node is valid against the schema, false otherwise
     */
    private static boolean validateAgainstSchema(GraphQLSchema schema, JsonNode dataNode) {
        // Start validation from the query type
        Map<String, GraphQLNamedType> typeMap = schema.getTypeMap();
        ObjectTypeDefinition queryType = (ObjectTypeDefinition) ((GraphQLObjectType) typeMap.get("Query")).getDefinition();

        return validateObject(queryType, dataNode, typeMap);
    }

    /**
     * Validates a JSON object node against the GraphQL object type definition.
     *
     * @param typeDefinition the GraphQL object type definition
     * @param dataNode the JSON object node to validate
     * @param typeMap the map of GraphQL named types
     * @return true if the object node is valid against the type definition, false otherwise
     */
    private static boolean validateObject(ObjectTypeDefinition typeDefinition, JsonNode dataNode, Map<String, GraphQLNamedType> typeMap) {
        for (var field : typeDefinition.getFieldDefinitions()) {
            if (!validateField(field, dataNode, typeMap)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Validates a JSON field node against the GraphQL field definition.
     *
     * @param field the GraphQL field definition
     * @param dataNode the JSON object node containing the field
     * @param typeMap the map of GraphQL named types
     * @return true if the field node is valid against the field definition, false otherwise
     */
    private static boolean validateField(graphql.language.FieldDefinition field, JsonNode dataNode, Map<String, GraphQLNamedType> typeMap) {
        String fieldName = field.getName();
        JsonNode fieldValue = dataNode.get(fieldName);

        if (!fieldName.equals("data") && fieldValue == null) {
            
            logger.error("Missing field: " + fieldName);
            return false;
        }

        return validateFieldType(field, fieldValue, typeMap);
    }

    /**
     * Validates a JSON field value against the GraphQL field type.
     *
     * @param field the GraphQL field definition
     * @param fieldValue the JSON field value to validate
     * @param typeMap the map of GraphQL named types
     * @return true if the field value is valid against the field type, false otherwise
     */
    private static boolean validateFieldType(graphql.language.FieldDefinition field, JsonNode fieldValue, Map<String, GraphQLNamedType> typeMap) {
        if (field.getType() instanceof TypeName) {
            String typeName = ((TypeName) field.getType()).getName();
            if (typeMap.containsKey(typeName)) {
                GraphQLNamedType fieldTypeDef = typeMap.get(typeName);
                if (fieldTypeDef instanceof GraphQLObjectType) {
                    return validateObject((ObjectTypeDefinition) ((GraphQLObjectType) fieldTypeDef).getDefinition(), fieldValue, typeMap);
                }
            }
        }
        return true;
    }
}
