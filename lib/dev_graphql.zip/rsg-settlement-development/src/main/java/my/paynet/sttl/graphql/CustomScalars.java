/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl.graphql;

import graphql.GraphQLContext;
import graphql.language.StringValue;
import graphql.schema.Coercing;
import graphql.schema.CoercingParseLiteralException;
import graphql.schema.CoercingParseValueException;
import graphql.schema.CoercingSerializeException;
import graphql.schema.GraphQLScalarType;

import java.util.Locale;
import java.util.Map;

/**
 * Utility class providing custom GraphQL scalar types.
 * <p>
 * This class defines custom scalar types for GraphQL, including LimitedString,
 * NumericString, and Date, with their respective coercing logic.
 * </p>
 *
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class CustomScalars {

    private static final String ERROR_EXPECT_STRING = "Expected a String";
    private static final String ERROR_INVALID_DATE = "Invalid Date Format";
    private static final String ERROR_INVALID_NUMERIC_STRING = "Invalid numeric string format";

    /**
     * Private constructor to prevent instantiation.
     */
    private CustomScalars() {
    }

    /**
     * GraphQL scalar type for strings with a limited length.
     * <p>
     * This scalar type ensures that the string length does not exceed 16 characters.
     * </p>
     */
    public static final GraphQLScalarType limitedString = GraphQLScalarType.newScalar()
            .name("LimitedString")
            .description("String with limited length")
            .coercing(new Coercing<String, String>() {
                @Override
                public String serialize(Object dataFetcherResult, GraphQLContext context, Locale locale) throws CoercingSerializeException {
                    if (!(dataFetcherResult instanceof String)) {
                        throw new CoercingSerializeException(ERROR_EXPECT_STRING);
                    }
                    return (String) dataFetcherResult;
                }

                @Override
                public String parseValue(Object input, GraphQLContext context, Locale locale) throws CoercingParseValueException {
                    if (!(input instanceof String)) {
                        throw new CoercingParseValueException(ERROR_EXPECT_STRING);
                    }
                    String value = (String) input;
                    if (value.length() > 16) {
                        throw new CoercingParseValueException("String exceeds maximum length of 16");
                    }
                    return value;
                }

     
                public String parseLiteral(Object input, Map<String, Object> variables, GraphQLContext context, Locale locale) throws CoercingParseLiteralException {
                    if (!(input instanceof StringValue)) {
                        throw new CoercingParseLiteralException(ERROR_EXPECT_STRING);
                    }
                    String value = ((StringValue) input).getValue();
                    if (value.length() > 16) {
                        throw new CoercingParseLiteralException("String exceeds maximum length of 16");
                    }
                    return value;
                }
            }).build();

    /**
     * GraphQL scalar type for strings containing numeric values.
     * <p>
     * This scalar type ensures that the string contains only numeric values.
     * </p>
     */
    public static final GraphQLScalarType numericString = GraphQLScalarType.newScalar()
            .name("NumericString")
            .description("String containing numeric values")
            .coercing(new Coercing<String, String>() {
                @Override
                public String serialize(Object dataFetcherResult, GraphQLContext context, Locale locale) throws CoercingSerializeException {
                    if (!(dataFetcherResult instanceof String)) {
                        throw new CoercingSerializeException(ERROR_EXPECT_STRING);
                    }
                    return (String) dataFetcherResult;
                }

                @Override
                public String parseValue(Object input, GraphQLContext context, Locale locale) throws CoercingParseValueException {
                    if (!(input instanceof String)) {
                        throw new CoercingParseValueException(ERROR_EXPECT_STRING);
                    }
                    String value = (String) input;
                    if (!value.matches("^\\d+(\\.\\d+)?$")) {
                        throw new CoercingParseValueException(ERROR_INVALID_NUMERIC_STRING);
                    }
                    return value;
                }

  
                public String parseLiteral(Object input, Map<String, Object> variables, GraphQLContext context, Locale locale) throws CoercingParseLiteralException {
                    if (!(input instanceof StringValue)) {
                        throw new CoercingParseLiteralException(ERROR_EXPECT_STRING);
                    }
                    String value = ((StringValue) input).getValue();
                    if (!value.matches("^\\d+(\\.\\d+)?$")) {
                        throw new CoercingParseLiteralException(ERROR_INVALID_NUMERIC_STRING);
                    }
                    return value;
                }
            }).build();

    /**
     * GraphQL scalar type for date strings.
     * <p>
     * This scalar type ensures that the string is in the format YYYY-MM-DD.
     * </p>
     */
    public static final GraphQLScalarType date = GraphQLScalarType.newScalar()
            .name("Date")
            .description("Custom date scalar type")
            .coercing(new Coercing<String, String>() {
                @Override
                public String serialize(Object dataFetcherResult, GraphQLContext context, Locale locale) throws CoercingSerializeException {
                    if (!(dataFetcherResult instanceof String)) {
                        throw new CoercingSerializeException(ERROR_EXPECT_STRING);
                    }
                    return (String) dataFetcherResult;
                }

                @Override
                public String parseValue(Object input, GraphQLContext context, Locale locale) throws CoercingParseValueException {
                    if (!(input instanceof String)) {
                        throw new CoercingParseValueException(ERROR_EXPECT_STRING);
                    }
                    String value = (String) input;
                    if (!value.matches("^\\d{4}-\\d{2}-\\d{2}$")) {
                        throw new CoercingParseValueException(ERROR_INVALID_DATE);
                    }
                    return value;
                }

   
                public String parseLiteral(Object input, Map<String, Object> variables, GraphQLContext context, Locale locale) throws CoercingParseLiteralException {
                    if (!(input instanceof StringValue)) {
                        throw new CoercingParseLiteralException(ERROR_EXPECT_STRING);
                    }
                    String value = ((StringValue) input).getValue();
                    if (!value.matches("^\\d{4}-\\d{2}-\\d{2}$")) {
                        throw new CoercingParseLiteralException(ERROR_INVALID_DATE);
                    }
                    return value;
                }
            }).build();
}
