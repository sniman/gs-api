/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl.graphql;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import my.paynet.sttl.model.Response;
import org.apache.hc.client5.http.HttpResponseException;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.util.Timeout;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import my.paynet.sttl.config.Config;
import my.paynet.sttl.scheduler.SlidingWindowScheduler;
import my.paynet.util.Utils;
import org.apache.hc.core5.http.HttpStatus;

/**
 * A client for executing GraphQL queries and processing responses.
 * <p>
 * This class handles sending GraphQL queries to a specified endpoint, handling
 * responses, and validating the returned data.
 * </p>
 *
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class GraphQLClient {

    private static final Logger logger = LoggerFactory.getLogger(GraphQLClient.class);
    private Config config;
    private String query;
    private static final String WINDOW_PLACEHOLDER = "XWINDOWX";
    private static final String DATE_PLACEHOLDER = "XDATE_PLACEHOLDERX";
    private static final String RENTAS = "Rentas";
    private static final String SAN = "SAN";
    private static final String MYDEBIT = "MyDebit";
    private static final String DATA = "data";

    /**
     * Constructs a new GraphQLClient with the specified configuration.
     *
     * @param config the configuration object containing settings for the
     * GraphQL client
     */
    public GraphQLClient(Config config) {
        try {
            this.config = config;
            this.query = this.readQueryFromClasspath(config.getGraphqlQueryFile());
        } catch (IOException ex) {
            logger.error(Utils.getStackTraceAsString(ex));
        }
    }

    /**
     * Reads the GraphQL query from the specified file in the classpath.
     *
     * @param filePath the path to the query file in the classpath
     * @return the content of the query file as a string
     * @throws IOException if an I/O error occurs while reading the file
     */
    public String readQueryFromClasspath(String filePath) throws IOException {
        ClassLoader classLoader = getClass().getClassLoader();
        try (InputStream inputStream = classLoader.getResourceAsStream(filePath)) {
            if (inputStream == null) {
                throw new IOException("File not found: " + filePath);
            }
            return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    /**
     * Executes a GraphQL query for the specified window and current date-time.
     *
     * @param window the name of the window (WINDOW-1 or WINDOW-2)
     * @param currDtTime the current LocalDateTime
     * @return the response from the GraphQL server
     * @throws IOException if an I/O error occurs
     * @throws URISyntaxException if a URI syntax error occurs
     * @throws java.text.ParseException if a parsing error occurs
     * @throws org.apache.hc.core5.http.ParseException if a HTTP parsing error
     * occurs
     */
    public Response query(String window, LocalDateTime currDtTime) throws IOException, URISyntaxException, java.text.ParseException, org.apache.hc.core5.http.ParseException {
        if (SlidingWindowScheduler.WINDOW1.equals(window)) {
            // Window 1 is taking files from the previous day
            return this.query(Utils.getDate(currDtTime, -1), "1");
        } else {
            // Window 2 is taking files from the current day
            return this.query(Utils.getDate(currDtTime, 0), "2");
        }
    }

    /**
     * Executes a GraphQL query for the specified window.
     *
     * @param window the name of the window (WINDOW-1 or WINDOW-2)
     * @return the response from the GraphQL server
     * @throws IOException if an I/O error occurs
     * @throws URISyntaxException if a URI syntax error occurs
     * @throws java.text.ParseException if a parsing error occurs
     * @throws org.apache.hc.core5.http.ParseException if a HTTP parsing error
     * occurs
     */
    public Response query(String window) throws IOException, URISyntaxException, java.text.ParseException, org.apache.hc.core5.http.ParseException {
        if (SlidingWindowScheduler.WINDOW1.equals(window)) {
            // Window 1 is taking files from the previous day
            return this.query(Utils.getCurrentDate(-1), "1");
        } else {
            // Window 2 is taking files from the current day
            return this.query(Utils.getCurrentDate(), "2");
        }
    }

    /**
     * Executes a GraphQL query with the specified date and window.
     *
     * @param date the date to use in the query
     * @param window the window to use in the query
     * @return the response from the GraphQL server
     * @throws IOException if an I/O error occurs
     * @throws URISyntaxException if a URI syntax error occurs
     * @throws java.text.ParseException if a parsing error occurs
     * @throws org.apache.hc.core5.http.ParseException if a HTTP parsing error
     * occurs
     */
    public Response query(String date, String window) throws IOException, URISyntaxException, java.text.ParseException, org.apache.hc.core5.http.ParseException {
        URI uri = new URI(this.config.getGraphqlUrl());
        HttpPost postRequest = new HttpPost(uri);
        postRequest.addHeader("Content-Type", "application/json");
        postRequest.addHeader("x-api-key", this.config.getGraphqlApiKey());

        // Replace content markers yyyy-MM-dd and XWINDOWX with parameters
        String qry = this.query.replace(DATE_PLACEHOLDER, date).replace(WINDOW_PLACEHOLDER, window);
        postRequest.setEntity(new StringEntity(qry, StandardCharsets.UTF_8));

        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(Timeout.ofSeconds(this.config.getConnectTimeout()))
                .setResponseTimeout(Timeout.ofSeconds(this.config.getReadTimeout()))
                .build();

        try (CloseableHttpClient httpClient = HttpClients.custom()
                .setDefaultRequestConfig(requestConfig)
                .build(); CloseableHttpResponse response = httpClient.execute(postRequest)) {

            int statusCode = response.getCode();
            if (statusCode != HttpStatus.SC_OK) {
                logger.error("Response Error:{}", statusCode);
                throw new HttpResponseException(statusCode, "Query failed with status code: " + statusCode);
            }

            String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            ObjectMapper mapper = new ObjectMapper();
            JsonNode jsonNode = mapper.readTree(responseBody);

            // Validate JSON response 
            if (!validateResponse(jsonNode)) {
                logger.error("Invalid response: {}", responseBody);
                return null;
            } else {
                boolean isOKResp = GraphQLValidator.validateResponse(config.getGraphqlSchemaFile(), jsonNode);

                if (isOKResp) {
                    // Deserialize JSON response into POJO
                    Response deserializedResponse = mapper.readValue(responseBody, Response.class);
                    logger.debug("Response {}", jsonNode.toPrettyString());
                    return deserializedResponse;
                } else {
                    logger.error("Invalid response!");
                    return null;
                }

            }
        } catch (HttpResponseException e) {
            logger.error("HTTP error occurred: {}", Utils.getStackTraceAsString(e));
            throw e;
        } catch (IOException | org.apache.hc.core5.http.ParseException e) {
            logger.error("I/O error occurred: {}", Utils.getStackTraceAsString(e));
            throw e;
        }
    }

    /**
     * Validates the JSON response from the GraphQL server.
     *
     * @param jsonNode the JSON response to validate
     * @return true if the response is valid, false otherwise
     */
    private boolean validateResponse(JsonNode jsonNode) {
        if (!jsonNode.has(DATA)) {
            return false;
        }

        JsonNode dataNode = jsonNode.get(DATA);
        boolean isValidMyDebit = dataNode.has(MYDEBIT)
                && dataNode.get(MYDEBIT).has(RENTAS)
                && dataNode.get(MYDEBIT).get(RENTAS).has(DATA);

        boolean isValidSan = dataNode.has(SAN)
                && dataNode.get(SAN).has(RENTAS)
                && dataNode.get(SAN).get(RENTAS).has(DATA);

        return isValidMyDebit || isValidSan;
    }

}
