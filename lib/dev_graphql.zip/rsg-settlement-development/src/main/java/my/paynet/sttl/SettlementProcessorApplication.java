/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl;

import my.paynet.sttl.config.Config;
import my.paynet.sttl.config.ConfigManager;
import my.paynet.sttl.scheduler.SlidingWindowScheduler;
import my.paynet.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class SettlementProcessorApplication {

    private static final Logger logger = LoggerFactory.getLogger(SettlementProcessorApplication.class);

    public static void main(String[] args) throws Exception {
        SettlementProcessorApplication spa = new SettlementProcessorApplication();
        spa.run();
    }

    public void run() throws Exception {

        String iniFilePath = System.getProperty("iniFilePath");
        String sectionName = System.getProperty("sectionName");
        logger.info("Starting SettlementProcessorApplication v1 for {}", sectionName);
        ConfigManager mgr = new ConfigManager();
        Config config = mgr.loadConfiguration(iniFilePath, sectionName);

        SlidingWindowScheduler sws = new SlidingWindowScheduler(config);
        sws.scheduleWindow(SlidingWindowScheduler.WINDOW1);
        sws.scheduleWindow(SlidingWindowScheduler.WINDOW2);
        sws.scheduleReportStatus();

        Runtime.getRuntime().addShutdownHook(new Thread(sws::shutdown));

        // Keep the main thread alive to allow scheduled tasks to run
        try {
            Thread.currentThread().join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("Main thread interrupted: {}", Utils.getStackTraceAsString(e));
        }
    }
}
