/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Rentas {
    @JsonProperty("data")
    private RentasData data;

    // Getters and Setters
    public RentasData getData() {
        return data;
    }

    public void setData(RentasData data) {
        this.data = data;
    }
}
