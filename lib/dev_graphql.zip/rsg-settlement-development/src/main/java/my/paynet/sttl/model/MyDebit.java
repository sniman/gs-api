/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MyDebit {
    @JsonProperty("Rentas")
    private Rentas rentas;

    // Getters and Setters
    public Rentas getRentas() {
        return rentas;
    }

    public void setRentas(Rentas rentas) {
        this.rentas = rentas;
    }
}
