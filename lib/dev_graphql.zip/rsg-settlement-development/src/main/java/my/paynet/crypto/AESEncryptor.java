/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.crypto;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import my.paynet.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class for AES encryption and decryption.
 * <p>
 * This class provides methods for generating AES keys, encrypting and
 * decrypting messages using AES/GCM/NoPadding.
 * </p>
 *
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class AESEncryptor {

    private static final Logger logger = LoggerFactory.getLogger(AESEncryptor.class);
    private static final int T_LEN = 128;
    private final String filePath;
    private byte[] iv;
    private SecretKeySpec keySpec;
    private static final String GCM = "AES/GCM/NoPadding";

    /**
     * Main method (mainly for testing) for running the AESEncryptor from the
     * command line.
     *
     * @param args command line arguments
     * @throws Exception if an error occurs during execution
     */
    public static void main(String[] args) throws Exception {
        logger.info("Number of Arguments {}", args.length);
        if (args.length == 0) {

            if (args.length == 2) {
                if (args[0].equals("--genkey")) {
                    AESEncryptor ae = new AESEncryptor(args[1]);
                    ae.generateKey();
                    logger.info("Key generated at: {}", args[1]);
                    System.exit(0);
                }
            } else if (args.length == 3) {
                AESEncryptor ae = new AESEncryptor(args[0], args[1]);
                ae.init();
                String msg = args[2];
                byte[] encryptedMessage = ae.encrypt(msg.getBytes(), ae.getKeySpec());
                String encodedMessage = Base64.getEncoder().encodeToString(encryptedMessage);
                logger.debug("Encrypted Message (Base64): " + encodedMessage);
                byte[] decryptedMessage = ae.decrypt(Base64.getDecoder().decode(encodedMessage), ae.getKeySpec());
                String decodedMessage = new String(decryptedMessage);
                logger.debug("Decrypted Message: " + decodedMessage);
                System.exit(0);
            }
        } else {
            logger.error("For KeyGeneration: java -cp <classpath to jar> AESEncryptor --genkey <absolute path to keyfile> ");
            logger.error("For Encryption: java -cp <classpath to jar> AESEncryptor <absolute path to keyfile> <12 bytes initialization vector> <Plaintext to be encrypted>");
            System.exit(-1);
        }
    }

    /**
     * Constructs an AESEncryptor with the specified file path and
     * initialization vector.
     *
     * @param path the path to the key file
     * @param initVector the initialization vector
     */
    public AESEncryptor(String path, String initVector) {
        this.filePath = path;
        this.iv = initVector.getBytes();
    }

    /**
     * Constructs an AESEncryptor with the specified file path and
     * initialization vector.
     *
     * @param path the path to the key file
     * @param initVector the initialization vector as a byte array
     */
    public AESEncryptor(String path, byte[] initVector) {
        this.filePath = path;
        this.iv = initVector;
    }

    /**
     * Constructs an AESEncryptor with the specified file path.
     *
     * @param path the path to the key file
     */
    public AESEncryptor(String path) {
        this.filePath = path;
    }

    /**
     * Initializes the AESEncryptor by reading the key from the file.
     */
    public void init() {
        try {
            this.keySpec = new SecretKeySpec(Files.readAllBytes(Paths.get(this.filePath)), "AES");
        } catch (IOException e) {
            logger.error(Utils.getStackTraceAsString(e));
        }
    }

    /**
     * Generates a new AES key and saves it to the specified file.
     */
    public void generateKey() {
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(256);
            SecretKey secretKey = keyGen.generateKey();

            try (FileOutputStream fos = new FileOutputStream(this.filePath)) {
                fos.write(secretKey.getEncoded());
            }

        } catch (NoSuchAlgorithmException | IOException e) {
            logger.error(Utils.getStackTraceAsString(e));
        }
    }

    /**
     * Encrypts the given message using the specified key.
     *
     * @param message the message to encrypt
     * @param key the AES key
     * @return the encrypted message with IV prefixed
     * @throws IllegalBlockSizeException if the message size is incorrect
     * @throws BadPaddingException if the padding is incorrect
     * @throws InvalidKeyException if the key is invalid
     * @throws InvalidAlgorithmParameterException if the algorithm parameters
     * are invalid
     * @throws NoSuchAlgorithmException if the AES algorithm is not available
     * @throws NoSuchPaddingException if the padding scheme is not available
     */
    public final byte[] encrypt(final byte[] message, final SecretKeySpec key) throws IllegalBlockSizeException, BadPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchPaddingException {
        Cipher cipher = Cipher.getInstance(GCM);

        GCMParameterSpec spec = new GCMParameterSpec(T_LEN, this.iv);
        cipher.init(Cipher.ENCRYPT_MODE, key, spec);

        byte[] cipherText = cipher.doFinal(message);

        // Prefix IV to cipherText for use in decryption
        byte[] cipherTextWithIv = new byte[iv.length + cipherText.length];
        System.arraycopy(iv, 0, cipherTextWithIv, 0, iv.length);
        System.arraycopy(cipherText, 0, cipherTextWithIv, iv.length, cipherText.length);

        return cipherTextWithIv;
    }

    /**
     * Decrypts the given cipher text with IV using the specified key.
     *
     * @param cipherTextWithIv the encrypted message with IV prefixed
     * @param key the AES key
     * @return the decrypted message
     * @throws IllegalBlockSizeException if the cipher text size is incorrect
     * @throws BadPaddingException if the padding is incorrect
     * @throws InvalidKeyException if the key is invalid
     * @throws InvalidAlgorithmParameterException if the algorithm parameters
     * are invalid
     * @throws NoSuchAlgorithmException if the AES algorithm is not available
     * @throws NoSuchPaddingException if the padding scheme is not available
     */
    public final byte[] decrypt(final byte[] cipherTextWithIv, final SecretKey key) throws IllegalBlockSizeException, BadPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchPaddingException {
        Cipher cipher = Cipher.getInstance(GCM);
        byte[] storeIV = new byte[12];
        System.arraycopy(cipherTextWithIv, 0, storeIV, 0, storeIV.length);

        GCMParameterSpec spec = new GCMParameterSpec(T_LEN, storeIV);
        cipher.init(Cipher.DECRYPT_MODE, key, spec);

        byte[] cipherText = new byte[cipherTextWithIv.length - storeIV.length];
        System.arraycopy(cipherTextWithIv, storeIV.length, cipherText, 0, cipherText.length);

        return cipher.doFinal(cipherText);
    }

    /**
     * Decrypts the given cipher text with IV using the internally stored key.
     *
     * @param cipherTextWithIv the encrypted message with IV prefixed
     * @return the decrypted message
     * @throws IllegalBlockSizeException if the cipher text size is incorrect
     * @throws BadPaddingException if the padding is incorrect
     * @throws InvalidKeyException if the key is invalid
     * @throws InvalidAlgorithmParameterException if the algorithm parameters
     * are invalid
     * @throws NoSuchAlgorithmException if the AES algorithm is not available
     * @throws NoSuchPaddingException if the padding scheme is not available
     */
    public final byte[] decrypt(final byte[] cipherTextWithIv) throws IllegalBlockSizeException, BadPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchPaddingException {
        Cipher cipher = Cipher.getInstance(GCM);
        byte[] storeIV = new byte[12];
        if (cipherTextWithIv.length < storeIV.length) {
            return new byte[0];
        } else {
            System.arraycopy(cipherTextWithIv, 0, storeIV, 0, storeIV.length);

            GCMParameterSpec spec = new GCMParameterSpec(T_LEN, storeIV);
            cipher.init(Cipher.DECRYPT_MODE, this.keySpec, spec);

            byte[] cipherText = new byte[cipherTextWithIv.length - storeIV.length];
            System.arraycopy(cipherTextWithIv, storeIV.length, cipherText, 0, cipherText.length);

            return cipher.doFinal(cipherText);
        }
    }

    /**
     * Gets the AES key specification.
     *
     * @return the key specification
     */
    private SecretKeySpec getKeySpec() {
        return keySpec;
    }
}
