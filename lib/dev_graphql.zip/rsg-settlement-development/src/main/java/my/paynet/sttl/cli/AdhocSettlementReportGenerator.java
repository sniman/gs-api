package my.paynet.sttl.cli;

import my.paynet.sttl.config.Config;
import my.paynet.sttl.config.ConfigManager;
import my.paynet.sttl.scheduler.SlidingWindowScheduler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
 * Adhoc Settlement Report Generator
 * <p>
 * This class generates settlement reports based on the provided window and
 * date. It utilizes the SlidingWindowScheduler to perform the task of
 * generating the report.
 * </p>
 *
 * @version 1.0
 * @since 2024-07-22
 * @author Tuan Sau-Wern <tuan.sauwern@paynet.my>
 * https://www.linkedin.com/in/ts-sau-wern-tuan-376b272a/
 */
public class AdhocSettlementReportGenerator {

    private static final Logger logger = LoggerFactory.getLogger(AdhocSettlementReportGenerator.class);
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /**
     * The main method of the Adhoc Settlement Report Generator.
     * <p>
     * Prompts the user for input, loads the configuration, and generates the
     * report.
     * </p>
     *
     * @param args the command line arguments (not used)
     */
    public static void main(String[] args) {
        logger.info("Starting ad hoc statement generator for RSG.");
        Scanner scanner = new Scanner(System.in);

        String iniFilePath = promptForIniFilePath(scanner);
        String sectionName = promptForSectionName(scanner);
        String window = promptForWindow(scanner);
        LocalDateTime dateTime = promptForDateTime(scanner);

        Config config = loadConfig(iniFilePath, sectionName);
        SlidingWindowScheduler scheduler = new SlidingWindowScheduler(config);

        try {
            boolean isGenerated = scheduler.performTask(window, dateTime);
            if (isGenerated) {
                logger.info("Report generated successfully for window {} on date {}", window, dateTime.format(DATE_FORMATTER));
            }else{
                logger.error("File generation failed!");
            }
        } catch (Exception e) {
            logger.error("Error generating report for window {} on date {}", window, dateTime.format(DATE_FORMATTER), e);
        }
    }

    /**
     * Prompts the user for the INI file path for configuration.
     *
     * @param scanner the Scanner object to read user input
     * @return the INI file path
     */
    public static String promptForIniFilePath(Scanner scanner) {
        while (true) {
            logger.info("Enter INI file path for configuration: ");
            String iniFilePath = scanner.nextLine().trim();
            if (!iniFilePath.isEmpty()) {
                return iniFilePath;
            } else {
                logger.info("INI file path cannot be empty. Please enter a valid path.");
            }
        }
    }

    /**
     * Prompts the user for the section name.
     * <p>
     * Valid section names are "san" or "mydebit".
     * </p>
     *
     * @param scanner the Scanner object to read user input
     * @return the section name
     */
    public static String promptForSectionName(Scanner scanner) {
        while (true) {
            logger.info("Enter section name (san or mydebit): ");
            String sectionName = scanner.nextLine().trim().toLowerCase();
            if ("san".equals(sectionName) || "mydebit".equals(sectionName)) {
                return sectionName;
            } else {
                logger.error("Invalid section name. Please enter 'san' or 'mydebit'.");
            }
        }
    }

    /**
     * Prompts the user for the window.
     * <p>
     * Valid windows are "WINDOW-1" or "WINDOW-2".
     * </p>
     *
     * @param scanner the Scanner object to read user input
     * @return the window
     */
    public static String promptForWindow(Scanner scanner) {
        while (true) {
            logger.info("Enter window (WINDOW-1 or WINDOW-2): ");
            String window = scanner.nextLine().trim();
            if ("WINDOW-1".equals(window) || "WINDOW-2".equals(window)) {
                return window;
            } else {
                logger.error("Invalid window. Please enter 'WINDOW-1' or 'WINDOW-2'.");
            }
        }
    }

    /**
     * Prompts the user for the date.
     * <p>
     * The date should be in yyyy-MM-dd format.
     * </p>
     *
     * @param scanner the Scanner object to read user input
     * @return the date as a LocalDateTime object
     */
    public static LocalDateTime promptForDateTime(Scanner scanner) {
        while (true) {
            logger.info("Enter date (yyyy-MM-dd): ");
            String dateTimeStr = scanner.nextLine().trim();
            try {
                return LocalDateTime.parse(dateTimeStr + "T00:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
            } catch (DateTimeParseException e) {
                logger.error("Invalid date format. Please use yyyy-MM-dd format.");
            }
        }
    }

    /**
     * Loads the configuration from the specified INI file and section.
     *
     * @param iniFilePath the path to the INI file
     * @param sectionName the section name in the INI file
     * @return the loaded Config object
     */
    public static Config loadConfig(String iniFilePath, String sectionName) {
        try {
            ConfigManager configManager = new ConfigManager();
            return configManager.loadConfiguration(iniFilePath, sectionName);
        } catch (Exception e) {
            logger.error("Error loading configuration: {}", e.getMessage());
            throw new IllegalArgumentException("Error loading configuration:" + e.getMessage());
        }
    }
}
