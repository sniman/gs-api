/*
 * © 2019-2024 Payments Network Malaysia Sdn Bhd (PayNet) 200801035403 (836743-D). All Rights Reserved.
 *
 * This software is copyrighted. Under the copyright laws, this software
 * may not be copied, in whole or in part, without prior written consent
 * of Payments Network Malaysia Sdn Bhd (PayNet).
 *  
 */
package my.paynet.sttl.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import my.paynet.util.Utils;

public class Total {

    @JsonProperty("records")
    private int records;

    @JsonProperty("float_amt")
    private String floatAmt;

    @JsonProperty("fee_charges")
    private String feeCharges;

    @JsonProperty("net_amt")
    private String netAmt;

    @JsonProperty("records_fmt")
    private String recordsFmt;

    @JsonProperty("float_amt_fmt")
    private String floatAmtFmt;

    @JsonProperty("float_amt_sign")
    private String floatAmtSign;

    @JsonProperty("fee_charges_fmt")
    private String feeChargesFmt;

    @JsonProperty("fee_charges_sign")
    private String feeChargesSign;

    @JsonProperty("net_amt_fmt")
    private String netAmtFmt;

    @JsonProperty("net_amt_sign")
    private String netAmtSign;

    // Getters and Setters
    public int getRecords() {
        return records;
    }

    public void setRecords(int records) {
        this.records = records;
    }

    public String getFloatAmt() {
        return floatAmt;
    }

    public void setFloatAmt(String floatAmt) {
        this.floatAmt = floatAmt;
    }

    public String getFeeCharges() {
        return feeCharges;
    }

    public void setFeeCharges(String feeCharges) {
        this.feeCharges = feeCharges;
    }

    public String getNetAmt() {
        return netAmt;
    }

    public void setNetAmt(String netAmt) {
        this.netAmt = netAmt;
    }

    public String getRecordsFmt() {
        return recordsFmt;
    }

    public void setRecordsFmt(String recordsFmt) {
        this.recordsFmt = recordsFmt;
    }

    public String getFloatAmtFmt() {
        return floatAmtFmt;
    }

    public void setFloatAmtFmt(String floatAmtFmt) {
        this.floatAmtFmt = floatAmtFmt;
    }

    public String getFloatAmtSign() {
        return floatAmtSign;
    }

    public void setFloatAmtSign(String floatAmtSign) {
        this.floatAmtSign = floatAmtSign;
    }

    public String getFeeChargesFmt() {
        return feeChargesFmt;
    }

    public void setFeeChargesFmt(String feeChargesFmt) {
        this.feeChargesFmt = feeChargesFmt;
    }

    public String getFeeChargesSign() {
        return feeChargesSign;
    }

    public void setFeeChargesSign(String feeChargesSign) {
        this.feeChargesSign = feeChargesSign;
    }

    public String getNetAmtFmt() {
        return netAmtFmt;
    }

    public void setNetAmtFmt(String netAmtFmt) {
        this.netAmtFmt = netAmtFmt;
    }

    public String getNetAmtSign() {
        return netAmtSign;
    }

    public void setNetAmtSign(String netAmtSign) {
        this.netAmtSign = netAmtSign;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Total{");
        sb.append("records=").append(records);
        sb.append(", floatAmt=").append(floatAmt);
        sb.append(", feeCharges=").append(feeCharges);
        sb.append(", netAmt=").append(netAmt);
        sb.append(", recordsFmt=").append(recordsFmt);
        sb.append(", floatAmtFmt=").append(floatAmtFmt);
        sb.append(", floatAmtSign=").append(floatAmtSign);
        sb.append(", feeChargesFmt=").append(feeChargesFmt);
        sb.append(", feeChargesSign=").append(feeChargesSign);
        sb.append(", netAmtFmt=").append(netAmtFmt);
        sb.append(", netAmtSign=").append(netAmtSign);
        sb.append('}');
        return sb.toString();
    }

    public String toReportTotal() {
        StringBuilder sb = new StringBuilder();
        sb.append("F");
        sb.append(Utils.padLeadingZeros(String.valueOf(records),6));
        sb.append(floatAmtFmt);
        sb.append(floatAmtSign);
        sb.append(feeChargesFmt);
        sb.append(feeChargesSign);
        sb.append(netAmtFmt);
        sb.append(netAmtSign);
        return sb.toString();
    }

}
